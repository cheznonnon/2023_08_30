// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_GDI_DIBSECTION
#define _H_NONNON_WIN32_GDI_DIBSECTION




#include "../../neutral/bmp.c"
#include "../../neutral/bmp/_fastcopy.c"

#include "../win/bitmap.c"




void
n_gdi_dibsection_zero( HBITMAP *h, n_bmp *b )
{

	(*h) = NULL;

	n_bmp_zero( b );


	return;
}

void
n_gdi_dibsection_exit( HBITMAP *h, n_bmp *b )
{

	if ( h != NULL )
	{
		n_win_bitmap_exit( (*h) );
		(*h) = NULL;
	}


	// [!] : don't use n_bmp_free() : double-free

	n_bmp_zero( b );


	return;
}

void
n_gdi_dibsection_init( HBITMAP *h, n_bmp *b, HWND hwnd, HDC hdc, n_type_gfx sx, n_type_gfx sy )
{

	n_posix_bool upsidedown = ( sy < 0 );

	if ( upsidedown ) { sy = abs( sy ); }


	// [!] : fail-safe

	if ( ( sx <= 0 )||( sy <= 0 ) )
	{
//n_posix_debug_literal( "Invalid Size : %d : %d", (int) sx, (int) sy );

		return;
	}


	n_gdi_dibsection_exit( h, b );


	n_bmp_header( b, sx,sy );


	n_posix_bool getdc_onoff = n_posix_false;

	if ( hdc == NULL )
	{
		getdc_onoff = n_posix_true;
		hdc = GetDC( hwnd );
	}

	BITMAPINFO bi = { N_BMP_INFOH( b ), { { 0,0,0,0 } } };

	if ( upsidedown ) { bi.bmiHeader.biHeight *= -1; }

	(*h) = CreateDIBSection
	(
		hdc,
		&bi,
		DIB_RGB_COLORS,
		(void**) &N_BMP_PTR( b ),
		NULL,
		0
	);

	if ( getdc_onoff )
	{
		ReleaseDC( hwnd, hdc );
	}


	return;
}

void
n_gdi_dibsection_replace( HBITMAP *h, n_bmp *b, HWND hwnd, n_bmp *from )
{

	n_type_gfx sx = N_BMP_SX( from );
	n_type_gfx sy = N_BMP_SY( from );


	n_gdi_dibsection_init( h,b, hwnd, NULL, sx,sy );

	n_bmp_flush_fastcopy( from, b );


	return;
}
/*
HBRUSH
n_gdi_dibsection_gridbrush( HWND hwnd, n_type_gfx size )
{

	// [Mechanism]
	//
	//	select HBRUSH and set PATCOPY to *Blt()


	const n_type_gfx border = 1;


	// [!] : fg : only green value is used
	// [!] : bg : zero means transparent

	const u32 fg = n_bmp_white;
	const u32 bg = n_bmp_black;


	HBITMAP hbmp;
	n_bmp   bmp;


	n_gdi_dibsection_zero( &hbmp, &bmp );
	n_gdi_dibsection_init( &hbmp, &bmp, hwnd, size,size );

	n_bmp_flush( &bmp, fg );
	n_bmp_box( &bmp, border, border, size - ( border * 2 ), size - ( border * 2 ), bg );

	HBRUSH hb_ret = CreatePatternBrush( hbmp );

	n_gdi_dibsection_exit( &hbmp, &bmp );


	return hb_ret;
}
*/

#endif // _H_NONNON_WIN32_GDI_DIBSECTION

