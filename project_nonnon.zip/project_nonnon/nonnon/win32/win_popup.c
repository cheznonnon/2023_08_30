// Popup Window Helper Functions
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_WIN_POPUP
#define _H_NONNON_WIN32_WIN_POPUP




#include "./sysinfo/version.c"

#include "./win.c"




void
n_win_popup_autostyle( HWND hwnd, n_type_gfx *csx, n_type_gfx *csy )
{

	n_win_style_dropshadow_onoff( hwnd, n_posix_true );

	n_win_exstyle_new( hwnd, WS_EX_TOOLWINDOW );

	n_type_gfx border_sx, border_sy;

	if ( n_win_style_is_classic() )
	{

		n_win_style_new( hwnd, WS_POPUP | WS_DLGFRAME );

		border_sx = GetSystemMetrics( SM_CXFIXEDFRAME );
		border_sy = GetSystemMetrics( SM_CYFIXEDFRAME );

	} else {

		// [!] : Win10 : a temporary setting
		//
		//	build 10130 : still needed
		//	build 10162 : still needed
		//	build 10240 : still needed

		if ( n_sysinfo_version_10_or_later() )
		{

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

			border_sx = GetSystemMetrics( SM_CXBORDER );
			border_sy = GetSystemMetrics( SM_CYBORDER );

		} else
		if ( n_win_dwm_is_on() )
		{

			// [x] : AnimateWindow() is not available

			n_win_style_new( hwnd, WS_POPUP | WS_SIZEBOX );

			border_sx = GetSystemMetrics( SM_CXSIZEFRAME );
			border_sy = GetSystemMetrics( SM_CYSIZEFRAME );

		} else {

			n_win_style_new( hwnd, WS_POPUP | WS_BORDER );

			border_sx = GetSystemMetrics( SM_CXBORDER );
			border_sy = GetSystemMetrics( SM_CYBORDER );

		}
	}

	if ( csx != NULL ) { (*csx) = border_sx; }
	if ( csy != NULL ) { (*csy) = border_sy; }


	return;
}

int
n_win_popup_automove( HWND hwnd, n_type_gfx csx, n_type_gfx csy )
{

	// Phase 1 : add frames

	n_win w; n_win_set( hwnd, &w, csx,csy, N_WIN_SET_CALCONLY );


	// Phase 2 : get current cursor position

	{

		POINT cursor;
		GetCursorPos( &cursor );

		w.posx = cursor.x;
		w.posy = cursor.y;
	}


	// Phase 3 : centering

	int taskbar; n_win_taskbarpos( &taskbar, NULL );

//n_txt_debug_printf_literal( "%d", taskbar );


	if ( ( taskbar == ABE_TOP )||( taskbar == ABE_BOTTOM ) )
	{
		w.posx -= w.wsx / 2;
	} else
	if ( ( taskbar == ABE_LEFT )||( taskbar == ABE_RIGHT ) )
	{
		w.posy -= w.wsy / 2;
	}


	// Phase 4 : drawing

	n_win_set( hwnd, &w, w.csx,w.csy, N_WIN_SET_NEEDPOS | N_WIN_SET_INNERPOS );


	return taskbar;
}

void
n_win_popup_patch( HWND hwnd, UINT msg, WPARAM *wparam, LPARAM *lparam, HWND hpopup )
{

	// [!] : suppress gray-out when "hpopup" is active

	switch( msg ) {

	case WM_NCACTIVATE :

		if ( (*wparam) == n_posix_false )
		{
			(*wparam) = IsWindow( hpopup );
		}

	break;

	} // switch


	// [!] : restoring is needed when "hpopup" is closed

	static n_posix_bool onoff = n_posix_false;

	if ( IsWindow( hpopup ) )
	{

		onoff = n_posix_true;

	} else
	if ( onoff )
	{

		onoff = n_posix_false;


		HWND         h       = n_win_cursor2hwnd();
		n_posix_bool restore = n_posix_false;


		if (
			( hwnd == h )
			||
			( IsChild(   hwnd, h ) )
			||
			( IsChild( hpopup, h ) )
		)
		{
			restore = n_posix_true;
		}


		n_win_message_send( hwnd, WM_NCACTIVATE, restore, 0 );


		// [!] : Win95 : hangup
		//
		//	don't use SetActiveWindow( hwnd );

		if ( restore ) { SetFocus( hwnd ); }

	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_POPUP

