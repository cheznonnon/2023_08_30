// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_win_txtbox_round_corner( n_win_txtbox *p, n_type_int text_y, n_type_gfx x, n_type_gfx y, u32 bg )
{

	if ( text_y != p->select_cch_y  ) { return; }
	if ( 0      == p->select_cch_sx ) { return; }


	if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
	{
		//
	} else
	if (
		( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		||
		( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
	)
	{

		n_type_gfx ncsx = ( p->border_pxl_sx + p->pad_pxl_sx + p->maclike_offset ) * 2;
		if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL ) { ncsx += p->scrollbar_pxl_sx; }

		if ( p->style_option & N_WIN_TXTBOX_OPTION_EDITBOX_LINENUM )
		{
			   x -= p->pad_pxl_sx;
			ncsx += p->number_pxl_sx + p->pad_pxl_sx;

			ncsx -= p->border_pxl_sx;
//n_win_txtbox_hwndprintf_literal( p, " %d %d %d ", ncsx, p->number_pxl_sx, ( p->pad_pxl_sx * 2 ) );
		}


		n_type_gfx tx,ty,tsx,tsy;

		tx  = x;
		ty  = y;
		tsx = 0;
		tsy = p->cell_pxl_sy;

		if ( p->style & N_WIN_TXTBOX_STYLE_LISTBOX )
		{
			n_type_gfx max_sx = p->client_pxl_sx - ncsx;

			n_posix_char *str = n_win_txtbox_txt_get( p, p->select_cch_y );

			SIZE size = n_win_txtbox_size_text( p, str );
			if ( size.cx > max_sx )
			{
				tsx = max_sx + p->roundrect_pxl;
			} else {
				tsx = max_sx;
			}
		} else
		if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE )
		{
			tx  = p->corner_pxl_ox;
			tsx = p->corner_pxl_osx;
		}


		n_type_gfx round_size = p->roundrect_pxl;
		n_type_gfx frame_size = 0;

		n_bmp_cornermask_internal( &p->bmp, tx,ty,tsx,tsy, round_size, frame_size, bg, bg, bg, bg );


		n_win_rect_set( &p->highlight_rect, tx,ty,tsx,tsy );

//n_bmp_box( &p->bmp, tx,ty,tsx,tsy, n_bmp_rgb( 0,200,255 ) );
	}


	return;
}

// internal
void
n_win_txtbox_draw_roundframe( n_win_txtbox *p, n_type_gfx border_sx, n_type_gfx border_sy, COLORREF color_fg )
{
//return;

	if ( NULL == N_BMP_PTR( &p->bmp ) ) { return; }


	u32 argb_bg = n_win_cornercolor_get( p->hwnd );


	n_type_gfx bmpsx = N_BMP_SX( &p->bmp );
	n_type_gfx bmpsy = N_BMP_SY( &p->bmp );

	n_bmp bmp_frame; n_bmp_zero( &bmp_frame ); n_bmp_1st_fast( &bmp_frame, bmpsx, bmpsy );

	bmp_frame.transparent_onoff = n_posix_false;


	n_type_gfx bx = border_sx;
	n_type_gfx by = border_sy;


	n_bmp_flush( &bmp_frame, argb_bg );


	if ( p->style_option & N_WIN_TXTBOX_OPTION_ONELINE_MACLIKE )
	{

		n_posix_bool patch_prev = n_bmp_roundrect_detect_coeff_patch_onoff;
		n_bmp_roundrect_detect_coeff_patch_onoff = n_posix_false;


		n_type_gfx o = n_posix_max_n_type_gfx( 1, p->maclike_offset );

		n_type_gfx  x = 0;
		n_type_gfx  y = 0;
		n_type_gfx sx = bmpsx;
		n_type_gfx sy = bmpsy;


		n_posix_bool is_selected = p->selected_border_onoff;

		if ( p->style_option & N_WIN_TXTBOX_OPTION_NO_FOCUS_CHANGE )
		{
			is_selected = n_posix_false;
		}


		u32 clr_border = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_fg ) );


		if ( is_selected )
		{
			n_type_real step = ( 1.0 / o );

			n_type_real ratio;
			if ( n_win_darkmode_onoff )
			{
				ratio = 0.66;
			} else {
				ratio = 0.33;
			}

			n_type_gfx i = 0;
			n_posix_loop
			{
				n_type_gfx  xx = x + i;
				n_type_gfx  yy = y + i;
				n_type_gfx sxx = sx - ( i * 2 );
				n_type_gfx syy = sy - ( i * 2 );

				u32 clr = n_bmp_blend_pixel( argb_bg, clr_border, (n_type_real) step * i * ratio );
				n_bmp_roundrect_pixel( &bmp_frame, xx,yy,sxx,syy, clr, p->roundrect_pxl );

				i++;
				if ( i >= o ) { break; }
			}
		}

		 x += o;
		 y += o;
		sx -= o * 2;
		sy -= o * 2;

		n_bmp_roundrect_pixel( &bmp_frame, x,y,sx,sy, clr_border, p->roundrect_pxl );

		 x += bx;
		 y += by;
		sx -= bx * 2;
		sy -= by * 2;

		u32 clr_padding = n_bmp_alpha_invisible_pixel( n_bmp_colorref2argb( p->color_back_noselect ) );
		n_bmp_roundrect_pixel( &bmp_frame, x,y,sx,sy, clr_padding, p->roundrect_pxl );


		n_bmp_roundrect_detect_coeff_patch_onoff = patch_prev;

	} else {

		u32 clr_border = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_fg ) );
		n_bmp_flush_roundrect_pixel( &bmp_frame, clr_border, p->roundrect_pxl );

		n_type_gfx  x = bx;
		n_type_gfx  y = by;
		n_type_gfx sx = p->client_pxl_sx - ( bx * 2 );
		n_type_gfx sy = p->client_pxl_sy - ( by * 2 );

		u32 clr_padding = n_bmp_alpha_invisible_pixel( n_bmp_colorref2argb( p->color_back_noselect ) );
		n_bmp_roundrect_pixel( &bmp_frame, x,y,sx,sy, clr_padding, p->roundrect_pxl );

	}


	n_bmp_flush_transcopy( &bmp_frame, &p->bmp );


//if ( p->style & N_WIN_TXTBOX_STYLE_ONELINE ) {} else { n_bmp_save_literal( &bmp_frame, "ret.bmp" ); }

	n_bmp_free_fast( &bmp_frame );


	return;
}

// internal
void
n_win_txtbox_draw_roundframe_combo( n_win_txtbox *p, COLORREF color_fg )
{
//return;

//color_fg = RGB( 255,0,0 );

	if ( NULL == N_BMP_PTR( &p->bmp ) ) { return; }


	if ( NULL == N_BMP_PTR( &p->bmp_roundfr ) )
	{
//u32 tick = n_posix_tickcount();

		n_type_gfx bmpsx = N_BMP_SX( &p->bmp );
		n_type_gfx bmpsy = N_BMP_SY( &p->bmp );

		n_bmp_1st_fast( &p->bmp_roundfr, bmpsx, bmpsy );
		p->bmp_roundfr.transparent_onoff = n_posix_false;

		//n_bmp_flush( &p->bmp_roundfr, n_bmp_white_invisible );

		if ( p->style & N_WIN_TXTBOX_STYLE_CMB_POP )
		{

			if ( NULL == N_BMP_PTR( &p->bmp_desktop ) )
			{
				n_win_fluent_ui_bmp_desktop( p->hwnd, &p->bmp_desktop );
			}

			RECT r; GetWindowRect( p->hwnd, &r );
			n_type_gfx rx,ry,rsx,rsy; n_win_rect_expand_range( &r, &rx,&ry,&rsx,&rsy );

			n_bmp_fastcopy( &p->bmp_desktop, &p->bmp_roundfr, rx,ry,bmpsx,bmpsy, 0,0 );
//n_bmp_save_literal( &p->bmp_desktop, "ret.bmp" );


			n_type_gfx round_param = p->roundrect_pxl;

			rsx = p->client_pxl_sx + ( p->shadow_l + p->shadow_r );
			rsy = p->client_pxl_sy + ( p->shadow_u + p->shadow_d );


			n_bmp map; n_bmp_zero( &map ); n_bmp_1st( &map, bmpsx,bmpsy );

			n_type_gfx  x = p->shadow_l;
			n_type_gfx  y = 0;
			n_type_gfx sx = p->client_pxl_sx;
			n_type_gfx sy = p->client_pxl_sy;

			n_bmp_ui_roundframe( &map, x,y,sx,sy, p->roundrect_pxl, p->scale, n_bmp_white, n_bmp_white );
			n_bmp_roundrect_bmp_map = &map;

//n_bmp_save_literal( &map, "map.bmp" );


			n_bmp_ui_roundframe_shadow( &p->bmp_roundfr, rsx,rsy, p->shadow_r, round_param, p->scale, n_win_darkmode_onoff, ( p->shadow_l == 0 ) );
//n_bmp_save_literal( &p->bmp_roundfr, "ret.bmp" );


			n_bmp_roundrect_bmp_map = NULL;
			n_bmp_free_fast( &map );

//n_bmp_flush( &p->bmp_roundfr, n_bmp_rgb( 0,200,255 ) );

		} else {

			u32 argb_bg = n_win_cornercolor_get( p->hwnd );
			n_bmp_flush( &p->bmp_roundfr, argb_bg );

		}


		u32 clr_padding = n_bmp_alpha_invisible_pixel( n_bmp_colorref2argb( p->color_back_noselect ) );
		u32 clr_border  = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_fg ) );

		n_type_gfx  x = p->shadow_l;
		n_type_gfx  y = 0;
		n_type_gfx sx = p->client_pxl_sx;
		n_type_gfx sy = p->client_pxl_sy;

		n_bmp_ui_roundframe( &p->bmp_roundfr, x,y,sx,sy, p->roundrect_pxl, p->scale, clr_border, clr_padding );

//n_win_txtbox_hwndprintf_literal( p, " %d ", (int) n_posix_tickcount() - tick );
	}


	n_bmp_flush_transcopy( &p->bmp_roundfr, &p->bmp );


	return;
}

// internal
void
n_win_txtbox_draw_alpha_visible( n_win_txtbox *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy )
{

	n_type_gfx xx = 0;
	n_type_gfx yy = 0;
	n_posix_loop
	{

		if ( n_bmp_ptr_is_accessible( &p->bmp, x+xx,y+yy ) )
		{
			u32 color; n_bmp_ptr_get_fast( &p->bmp, x+xx,y+yy, &color );

			int a = n_bmp_a( color );

			if ( a != N_BMP_ALPHA_CHANNEL_VISIBLE )
			{
				n_bmp_ptr_set_fast( &p->bmp, x+xx,y+yy, n_bmp_alpha_visible_pixel( color ) );
			}
		}

		xx++;
		if ( xx >= sx )
		{

			xx = 0;

			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}

// internal
void
n_win_txtbox_bmp_alpha_enhancer( n_bmp *bmp, n_type_real ratio )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];
		if ( N_BMP_ALPHA_CHANNEL_INVISIBLE != n_bmp_a( color ) )
		{
			N_BMP_PTR( bmp )[ i ] = n_bmp_blend_pixel( color, n_bmp_white, ratio );
		}

		i++;
		if ( i >= c ) { break; }
	}


	return;
}

// internal
void
n_win_txtbox_bmp_alpha_reducer( n_bmp *bmp, n_type_real ratio )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];
		if ( color != n_bmp_white )
		{
			N_BMP_PTR( bmp )[ i ] = n_bmp_blend_pixel( color, n_bmp_black, ratio );
		}

		i++;
		if ( i >= c ) { break; }
	}


	return;
}


