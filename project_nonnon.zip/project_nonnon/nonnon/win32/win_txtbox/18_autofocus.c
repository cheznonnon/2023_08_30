// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_win_txtbox_autofocus( n_win_txtbox *p, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	// [Needed] : set zero for x : when call many times

	p->scroll_pxl_tabbed_x = 0;//p->select_cch_x - ( p->page_pxl_tabbed_sx / 2 );
	p->scroll_pxl_tabbed_y = ( p->select_cch_y * p->cell_pxl_sy ) - ( p->page_pxl_tabbed_sy / 2 );
//n_posix_debug_literal( " %d : %d ", p->scroll_pxl_tabbed_y, p->select_cch_y );


	n_type_int sel_x  = p->select_cch_x;
	n_type_int sel_y  = p->select_cch_y;
	n_type_int sel_sx = p->select_cch_sx;

	n_type_int txt_fx = 0; n_win_txtbox_tabbedmetrics( p, sel_y, -1,sel_x,-1, NULL,NULL,&txt_fx );
	n_type_int txt_tx = txt_fx + sel_sx;
	n_type_int scr_fx = p->scroll_pxl_tabbed_x / p->font_pxl_sx;
	n_type_int scr_tx = scr_fx + ( p->page_pxl_tabbed_sx / p->font_pxl_sx );

	if (
		( txt_fx < scr_fx )
		||
		( txt_tx > scr_tx )
	)
	{
		p->scroll_pxl_tabbed_x = ( txt_tx * p->font_pxl_sx ) - ( p->page_pxl_tabbed_sx / 2 );
	}


	// [Needed] : clamp when resized

	n_win_txtbox_scroll( p, p->scroll_pxl_tabbed_x, p->scroll_pxl_tabbed_y );


	// [!] : some functions rewrite position for calling through WM_COMMAND

	p->hscr.unit_pos = 0;
	p->vscr.unit_pos = 0;


	if ( p->combo_popup_slide_onoff )
	{
		//
	} else
	//
	{
		extern void n_win_txtbox_draw_scrollbars( n_win_txtbox *p, n_posix_bool redraw );
		n_win_txtbox_draw_scrollbars( p, redraw );
//n_posix_debug_literal( " %f ", p->vscr.unit_pos );
	}


	// [Needed] : Win9x : reason is unknown

	if ( p->style & N_WIN_TXTBOX_STYLE_HSCROLL )
	{
		n_win_scrollbar_refresh( &p->hscr );
	}

	if ( p->style & N_WIN_TXTBOX_STYLE_VSCROLL )
	{
		n_win_scrollbar_refresh( &p->vscr );
	}


	return;
}

void
n_win_txtbox_autofocus_smart( n_win_txtbox *p, n_posix_bool redraw )
{

	if ( p == NULL ) { return; }


	n_type_int f = p->select_cch_y;
	n_type_int t = p->select_cch_y + p->select_cch_sy;

	f *= p->cell_pxl_sy;
	t *= p->cell_pxl_sy;

	n_type_int c = p->scroll_pxl_tabbed_y + p->page_pxl_tabbed_sy;

	c /= p->cell_pxl_sy;

	if (
		(
			( p->scroll_pxl_tabbed_y > f )
			&&
			( p->scroll_pxl_tabbed_y > t )
		)
		||
		( c < p->select_cch_y )
	)
	{
		n_win_txtbox_autofocus( p, redraw );
	}


	return;
}

#define n_win_txtbox_str2index_literal( p, s, b ) n_win_txtbox_str2index( p, n_posix_literal( s ), b )

n_type_int
n_win_txtbox_str2index( n_win_txtbox *p, const n_posix_char *str, n_posix_bool autoselect )
{

	// [!] : be sure to check a returned value


	if ( p == NULL ) { return N_WIN_TXTBOX_NOT_SELECTED; }


	n_type_int i = 0;
	n_posix_loop
	{

		if ( n_string_is_same( str, n_win_txtbox_txt_get( p, i ) ) ) { break; }

		i++;
		if ( i >= p->txt.sy ) { return N_WIN_TXTBOX_NOT_SELECTED; }
	}


	if ( autoselect )
	{
		n_win_txtbox_line_select( p, i );
		n_win_txtbox_autofocus( p, n_posix_false );
		n_win_txtbox_refresh( p, N_WIN_TXTBOX_STR2INDEX );
	}


	return i;
}


