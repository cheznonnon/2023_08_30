// Nonnon Win
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Version 9.0 ]
//
//	1.0 : initial release
//	2.0 : scroll_pixel()/unit() have three modes
//	3.0 : thumb calculation is removed
//	4.0 : OrangeCat Mode is implemented
//	5.0 : redraw count is reduced
//	6.0 : mainbuffer is implemented, rapid fire is re-tuned, fade_go() is made
//	7.0 : scroll_pixel()/unit() will not accept when delta is zero
//	8.0 : n_win_scrollbar_on_drag() behavior is changed
//	9.0 : option-ify "n_win_scrollbar_direct_render"




// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//		n_win_scrollbar_zero()
//		n_win_scrollbar_init()
//
//	[ WM_CLOSE ]
//
//		n_win_scrollbar_exit()
//
//	[ WM_COMMAND ]
//
//		n_win_scrollbar_draw_always( p, n_posix_true )
//
//		+ auto-arrow-disabler needs n_win_scrollbar_draw_always()
//
//		+ WPARAM : scroll position by unit
//		+ LPARAM : HWND to check
//
//	[ WM_SETTINGCHANGE ]
//
//		n_win_scrollbar_on_settingchange()
//
//		+ this module is also used by .style and .option are manually set
//
//	[ WM_MOUSEWHEEL ]
//
//		n_win_scrollbar_wheeldelta()
//		n_win_scrollbar_draw_always( p, n_posix_true )
//
//		+ auto-arrow-disabler needs n_win_scrollbar_draw_always()
//
//	[ WndProc() ]
//
//		n_win_scrollbar_proc()
//		n_win_scrollbar_subclass()
//
//		n_win_simplemenu_proc()
//
//	[ Subclass ]
//
//		n_win_scrollbar_subclass()
//
//	[ Scrollbar Initialization ]
//
//		n_win_scrollbar_parameter()
//
//		+ call n_win_scrollbar_refresh()
//
//	[ .style ]
//
//		auto-selection available when nothing is set
//
//	[ .option ]
//
//		N_WIN_SCROLLBAR_OPTION_NONE
//
//		+ zero, neutral state
//
//		N_WIN_SCROLLBAR_OPTION_NO_ARROWS
//
//		+ arrow buttons are not used
//
//		N_WIN_SCROLLBAR_OPTION_PAGER
//
//		+ jump when shaft is clicked
//
//		N_WIN_SCROLLBAR_OPTION_DRAW_100PC
//
//		+ draw thumb when 100%
//
//		N_WIN_SCROLLBAR_OPTION_USE_DI_HDC
//
//		+ for game loop : maybe useless, use N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER
//
//		N_WIN_SCROLLBAR_OPTION_DWM_ON
//
//		+ Vista/7 Aero Glass support
//
//		N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX
//
//		+ for OrangeCat like programs
//
//		N_WIN_SCROLLBAR_OPTION_CLAMP_BIG_THUMB
//
//		+ for TxtBox like programs
//
//		N_WIN_SCROLLBAR_OPTION_BIG_ARROWS
//
//		+ for IE11 like arrow buttons
//
//		N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR
//
//		+ .color_sh_fg/bg are used
//
//		N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER
//
//		[x] : currently CatPad / OrangeCat only works, Neko no Te is not
//
//		+ direct render on/off
//		+ set .bmp_backbuffer / .direct_render_callback / .direct_render_callback_data
//
//	[ Tweakers ]
//
//		[ n_posix_bool n_win_scrollbar_direct_render ]
//
//		not use static ownerdraw
//		for game loop
//
//		+ default is OFF
//
//		[ n_posix_bool n_win_scrollbar_parameter_add_page ]
//
//		use auto page addition
//
//		+ default is ON
//
//	[ Tips ]
//
//		[ the system has three modes ]
//
//			1 :  unit_* : user defined unit
//			2 : pixel_* : shaft based pixel
//			3 : re-calculation when a thumb has minimal size
//
//		[ when redraw request is no effect ]
//
//			a : n_win_scrollbar_refresh()
//			b : n_win_scrollbar_refresh_cache()
//			c : n_win_scrollbar_refresh_redraw_area()




#ifndef _H_NONNON_WIN32_WIN_SCROLLBAR
#define _H_NONNON_WIN32_WIN_SCROLLBAR




#include "../neutral/bmp/all.c"

#include "./win.c"
#include "./win_simplemenu.c"

#include "./gdi.c"
#include "./gdi/bitmap.c"

#include "./uxtheme.c"

//#include "./../game/gdiplus.c"




// [Patch] : for Visual Style (UxTheme)

enum n_SCROLLBARPARTS
{
	n_SBP_ARROWBTN       =  1,

	n_SBP_THUMBBTNHORZ   =  2,
	n_SBP_THUMBBTNVERT   =  3,

	n_SBP_LOWERTRACKHORZ =  4,
	n_SBP_UPPERTRACKHORZ =  5,

	n_SBP_LOWERTRACKVERT =  6,
	n_SBP_UPPERTRACKVERT =  7,

	n_SBP_GRIPPERHORZ    =  8,
	n_SBP_GRIPPERVERT    =  9,

	n_SBP_SIZEBOX        = 10
};

// [!] : this is confused and useless : use n_ARROWBTNSTATES for state codes

enum n_SCROLLBARSTYLESTATES
{
	n_SCRBS_NORMAL   = 1,
	n_SCRBS_HOT      = 2,
	n_SCRBS_PRESSED  = 3,
	n_SCRBS_DISABLED = 4,
	n_SCRBS_HOVER    = 5
};

enum n_ARROWBTNSTATES
{
	n_ABS_UPNORMAL      =  1,
	n_ABS_UPHOT         =  2,
	n_ABS_UPPRESSED     =  3,
	n_ABS_UPDISABLED    =  4,

	n_ABS_DOWNNORMAL    =  5,
	n_ABS_DOWNHOT       =  6,
	n_ABS_DOWNPRESSED   =  7,
	n_ABS_DOWNDISABLED  =  8,

	n_ABS_LEFTNORMAL    =  9,
	n_ABS_LEFTHOT       = 10,
	n_ABS_LEFTPRESSED   = 11,
	n_ABS_LEFTDISABLED  = 12,

	n_ABS_RIGHTNORMAL   = 13,
	n_ABS_RIGHTHOT      = 14,
	n_ABS_RIGHTPRESSED  = 15,
	n_ABS_RIGHTDISABLED = 16,

	n_ABS_UPHOVER       = 17,
	n_ABS_DOWNHOVER     = 18,
	n_ABS_LEFTHOVER     = 19,
	n_ABS_RIGHTHOVER    = 20
};




void
n_win_scrollbar_bmp_checker( n_bmp *bmp, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, u32 color )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx xx = 0;
	n_type_gfx yy = 0;
	n_posix_loop
	{

		if ( n_bmp_moire_detect( xx, yy, 1 ) )
		{
			n_bmp_ptr_set( bmp, xx + x, yy + y, color );
		}

		xx++;
		if ( xx >= sx )
		{
			xx = 0;
			yy++;
			if ( yy >= sy ) { break; }
		}
	}


	return;
}

void
n_win_scrollbar_bmp_alpha_replacer( n_bmp *bmp, int alpha )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		int a = alpha;
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		N_BMP_PTR( bmp )[ i ] = n_bmp_argb( a,r,g,b );


		i++;
		if ( i >= c ) { break; }
	}


	return;
}

void
n_win_scrollbar_bmp_alpha_partially_visible( n_bmp *bmp )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color = N_BMP_PTR( bmp )[ i ];

		int a = n_bmp_a( color );
		int r = n_bmp_r( color );
		int g = n_bmp_g( color );
		int b = n_bmp_b( color );

		if ( a != 0 ) { a = 255; }

		N_BMP_PTR( bmp )[ i ] = n_bmp_argb( a,r,g,b );


		i++;
		if ( i >= c ) { break; }
	}


	return;
}




int
n_win_scrollbar_wheeldelta( WPARAM wparam, UINT unit, n_posix_bool is_text )
{

	// [!] : also see n_win_msgloop() @ win32/win.c

	n_posix_char *str_class = n_posix_literal( "MouseZ" );
	n_posix_char *str_title = n_posix_literal( "Magellan MSWHEEL" );

	HWND          hwnd  = FindWindow( str_class, str_title );
	UINT          msg   = RegisterWindowMessage( n_posix_literal( "MSH_WHEELSUPPORT_MSG" ) );
	n_posix_bool  onoff = (n_posix_bool) n_win_message_send( hwnd, msg, 0, 0 );

	int delta = (s16) HIWORD( wparam ) / WHEEL_DELTA;
	if ( delta == 0 ) { return 0; } else { delta *= -1; }

	if ( is_text == n_posix_false ) { return delta; }

	if ( onoff )
	{
//n_posix_debug_literal( "IntelliPoint is ON" );

		if ( unit == 0 )
		{

			UINT msg_scrol_lines = RegisterWindowMessage( n_posix_literal( "MSH_SCROLL_LINES_MSG" ) );

			unit = (UINT) n_win_message_send( hwnd, msg_scrol_lines, 0, 0 );

		}

	} else {
//n_posix_debug_literal( "IntelliPoint is OFF" );

		if ( unit == 0 )
		{
			SystemParametersInfo( SPI_GETWHEELSCROLLLINES, 0, &unit, 0 );
		}

	}


	return unit * delta;
}

void
n_win_scrollbar_flush_mixer( n_bmp *bmp, u32 color_mix, n_type_real blend )
{

	n_type_int c = N_BMP_SX( bmp ) * N_BMP_SY( bmp );
	n_type_int i = 0;
	n_posix_loop
	{

		u32 color_f = N_BMP_PTR( bmp )[ i ];

		if (
			( n_posix_false == n_bmp_is_trans( bmp, color_f ) )
			&&
			( N_BMP_ALPHA_CHANNEL_INVISIBLE != n_bmp_a( color_f ) )
		)
		{
			u32 color_t = n_bmp_blend_pixel( color_f, color_mix, blend );
			if ( color_f != color_t )
			{
				N_BMP_PTR( bmp )[ i ] = color_t;
			}
		}


		i++;
		if ( i >= c ) { break; }
	}


	return;
}




#define  N_WIN_SCROLLBAR_RECT_NONE ( -11 ) // [!] : for debugging




typedef struct {

	n_type_real x,y,sx,sy;

} n_win_scrollbar_rect;




#define n_win_scrollbar_rect_reset( p ) n_win_scrollbar_rect_set( p, N_WIN_SCROLLBAR_RECT_NONE,N_WIN_SCROLLBAR_RECT_NONE,N_WIN_SCROLLBAR_RECT_NONE,N_WIN_SCROLLBAR_RECT_NONE )

void
n_win_scrollbar_rect_get( n_win_scrollbar_rect *p, n_type_real *x, n_type_real *y, n_type_real *sx, n_type_real *sy )
{

	if (  x != NULL ) { (* x) = p-> x; }
	if (  y != NULL ) { (* y) = p-> y; }
	if ( sx != NULL ) { (*sx) = p->sx; }
	if ( sy != NULL ) { (*sy) = p->sy; }


	return;
}

void
n_win_scrollbar_rect_set( n_win_scrollbar_rect *p, n_type_real x, n_type_real y, n_type_real sx, n_type_real sy )
{

	p->x  = x;
	p->y  = y;
	p->sx = sx;
	p->sy = sy;


	return;
}

n_posix_bool
n_win_scrollbar_rect_is_hovered( n_win_scrollbar_rect *p, HWND hwnd )
{
	return n_win_is_hovered_offset( hwnd, (n_type_gfx) p->x, (n_type_gfx) p->y, (n_type_gfx) p->sx, (n_type_gfx) p->sy );
}




#define N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL      ( 0 )
#define N_WIN_SCROLLBAR_LAYOUT_VERTICAL        ( 1 )

#define N_WIN_SCROLLBAR_STYLE_AUTO             ( 0 )
#define N_WIN_SCROLLBAR_STYLE_CLASSIC          ( 1 )
#define N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT     ( 2 )
#define N_WIN_SCROLLBAR_STYLE_SOLID            ( 3 )
#define N_WIN_SCROLLBAR_STYLE_VISUALSTYLE      ( 4 )
#define N_WIN_SCROLLBAR_STYLE_STRIPE           ( 5 )
#define N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND     ( 6 )
#define N_WIN_SCROLLBAR_STYLE_FLUENT_UI        ( 7 )

#define N_WIN_SCROLLBAR_OPTION_NONE            ( 0 <<  0 )
#define N_WIN_SCROLLBAR_OPTION_NO_ARROWS       ( 1 <<  0 )
#define N_WIN_SCROLLBAR_OPTION_PAGER           ( 1 <<  1 )
#define N_WIN_SCROLLBAR_OPTION_DRAW_100PC      ( 1 <<  2 )
#define N_WIN_SCROLLBAR_OPTION_USE_DI_HDC      ( 1 <<  3 )
#define N_WIN_SCROLLBAR_OPTION_DWM_ON          ( 1 <<  4 )
#define N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX ( 1 <<  5 )
#define N_WIN_SCROLLBAR_OPTION_CLAMP_BIG_THUMB ( 1 <<  6 )
#define N_WIN_SCROLLBAR_OPTION_NO_FASTMODE     ( 1 <<  7 )
#define N_WIN_SCROLLBAR_OPTION_BIG_ARROWS      ( 1 <<  8 )
#define N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR     ( 1 <<  9 )
#define N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER   ( 1 << 10 )

#define N_WIN_SCROLLBAR_SCROLL_NONE            ( 0 )
#define N_WIN_SCROLLBAR_SCROLL_SEND            ( 1 )
#define N_WIN_SCROLLBAR_SCROLL_AUTO            ( 2 )

#define N_WIN_SCROLLBAR_INTERVAL_PRESS         ( 400 )
#define N_WIN_SCROLLBAR_INTERVAL_EVENT         (   1 )

#define N_WIN_SCROLBAR_SCROLL_HERE             ( 0 )
#define N_WIN_SCROLBAR_LINE_0                  ( 1 )
#define N_WIN_SCROLBAR_MIN                     ( 2 )
#define N_WIN_SCROLBAR_MAX                     ( 3 )

#define N_WIN_SCROLLBAR_BLEND                  ( 0.25 )
#define N_WIN_SCROLLBAR_BLEND_THUMB            ( 0.33 )




typedef void (*n_win_scrollbar_callback_type)( void *data );




typedef struct {

	HWND                 hwnd;
	HWND                 hwnd_parent;
	HDC                  hdc;
	n_bmp               *bmp_backbuffer;
	n_bmp                bmp_mainbuffer;
	n_bmp               *bmp_parent;
	int                  layout;
	int                  style;
	int                  option;
	int                  stripe_type;
	n_type_gfx           scale;

	n_win_simplemenu     menu;

	n_posix_bool         fade_onoff;
	n_bmp_fade           fade_thumb;
	n_bmp_fade           fade_arrow_ul;
	n_bmp_fade           fade_arrow_dr;
	u32                  fade_color_thumb;
	u32                  fade_color_arrow_ul;
	u32                  fade_color_arrow_dr;

	u32                  color_trans;
	u32                  color__back;
	u32                  color_arbtn;
	u32                  color_thumb;
	u32                  color_bordr;
	u32                  color_shaft;
	u32                  color_press;
	u32                  color_hvr_t;
	u32                  color_hvr_s;
	u32                  color_arrow;
	u32                  color_sh_fg;
	u32                  color_sh_bg;

	u32                  color_edge_ul;
	u32                  color_edge_ur;
	u32                  color_edge_dl;
	u32                  color_edge_dr;

	n_type_real          unit_pos , pixel_pos;
	n_type_real          unit_max , pixel_max;
	n_type_real          unit_page, pixel_page;
	n_type_real          unit_step, pixel_step;
	n_type_real          unit_max_original;
	n_type_real          pixel_thumb_original;
	n_type_real          pixel_thumb;
	n_type_real          pixel_minim;
	n_type_real          pixel_arrow_sx, pixel_arrow_sy;
	n_type_real          pixel_shaft;
	n_type_real          pixel_offset;
	n_type_real          pixel_offset_prv;
	n_type_real          pixel_patch;
	n_type_real          prev_pos;

	n_win_scrollbar_rect rect_main;
	n_win_scrollbar_rect rect_shaft;
	n_win_scrollbar_rect rect_thumb;
	n_win_scrollbar_rect rect_arrow_ul;
	n_win_scrollbar_rect rect_arrow_dr;

	n_posix_bool         enabled;
	n_posix_bool         enabled_ul;
	n_posix_bool         enabled_dr;

	n_type_gfx           sx,sy;

	n_type_gfx           prv_cursor_x;
	n_type_gfx           prv_cursor_y;
	n_type_gfx           cur_cursor_x;
	n_type_gfx           cur_cursor_y;

	n_type_gfx           redraw_x;
	n_type_gfx           redraw_y;
	n_type_gfx           redraw_sx;
	n_type_gfx           redraw_sy;
	n_posix_bool         redraw_count;

	UINT                 timer_id;
	u32                  timer_pressing;
	u32                  rapid_fire;

	HWND                 pressed_hwnd;
	n_posix_bool         pressed_thumb;
	n_posix_bool         pressed_shaft;
	n_posix_bool         pressed_arrow_ul;
	n_posix_bool         pressed_arrow_dr;

	n_posix_bool         hovered_main;
	n_posix_bool         hovered_thumb;
	n_posix_bool         hovered_shaft;
	n_posix_bool         hovered_arrow_ul;
	n_posix_bool         hovered_arrow_dr;

	n_bmp                bmp_sh;
	n_bmp                bmp_ul;
	n_bmp                bmp_dr;
	n_bmp                bmp_th;
	n_bmp                bmp_gr;

	n_posix_bool         win8_onoff;
	n_posix_bool         drag_onoff;
	n_posix_bool         drag_clamp;
	n_posix_bool         show_onoff;
	n_posix_bool         stop_onoff;
	n_posix_bool         init_onoff;

	n_posix_bool         corner_onoff;

	n_posix_bool         arrow_is_event_running;

	n_win_scrollbar_callback_type  direct_render_callback;
	void                          *direct_render_callback_data;

} n_win_scrollbar;




//static n_win_scrollbar *n_win_scrollbar_debug_instance = NULL;




#define n_win_scrollbar_hwndprintf(         p, f, ... ) n_win_hwndprintf( n_win_hwnd_toplevel( ( p )->hwnd ), f, ##__VA_ARGS__ )
#define n_win_scrollbar_hwndprintf_literal( p, f, ... ) n_win_scrollbar_hwndprintf( p, n_posix_literal( f ), ##__VA_ARGS__ )
#define n_win_scrollbar_debug_count(                  ) n_win_debug_count( n_win_hwnd_toplevel( ( p )->hwnd ) )




n_posix_bool
n_win_scrollbar_is_thumb_minimal( n_win_scrollbar *p )
{

	n_posix_bool ret = n_posix_false;

	if ( p->pixel_thumb_original < p->pixel_thumb )
	{
		ret = n_posix_true;
	}
/*
if ( n_win_is_input( VK_CONTROL ) )
{
	n_posix_debug_literal( " %d : %g %g %g ", ret, p->pixel_thumb_original, p->pixel_thumb, p->pixel_minim );
}
*/
	return ret;
}




n_posix_bool
n_win_scrollbar_ui_uxtheme( n_win_scrollbar *p )
{

	if ( p->style != N_WIN_SCROLLBAR_STYLE_VISUALSTYLE ) { return n_posix_false; }


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, p->hwnd, L"SCROLLBAR" );

	if ( uxtheme.onoff == n_posix_false ) { n_uxtheme_exit( &uxtheme, p->hwnd ); return n_posix_false; }


	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		//

	} else {

		n_type_gfx sx = (n_type_gfx) p->rect_arrow_ul.sx;
		n_type_gfx sy = (n_type_gfx) p->rect_arrow_ul.sy;

		RECT rect = { 0,0,sx,sy };


		HDC hdc = n_gdi_doublebuffer_simple_init( p->hwnd, sx,sy );


		int part  = 0;
		int state = 0;


		if ( p->fade_arrow_ul.color_bg == p->color_arbtn )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTNORMAL;
			} else {
				state = n_ABS_UPNORMAL;
			}
		} else
		if ( p->fade_arrow_ul.color_bg == p->color_press )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTPRESSED;
			} else {
				state = n_ABS_UPPRESSED;
			}
		} else
		if ( p->fade_arrow_ul.color_bg == p->color_hvr_t )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTHOT;
			} else {
				state = n_ABS_UPHOT;
			}
		} else
		if ( p->fade_arrow_ul.color_bg == p->color_hvr_s )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTHOT;
			} else {
				state = n_ABS_UPHOT;
			}
		}

		if ( p->enabled_ul == n_posix_false )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTDISABLED;
			} else {
				state = n_ABS_UPDISABLED;
			}
		}

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		n_bmp bmp_f; n_bmp_zero( &bmp_f ); n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_f );


		if ( p->fade_arrow_ul.color_fg == p->color_arbtn )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTNORMAL;
			} else {
				state = n_ABS_UPNORMAL;
			}
		} else
		if ( p->fade_arrow_ul.color_fg == p->color_press )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTPRESSED;
			} else {
				state = n_ABS_UPPRESSED;
			}
		} else
		if ( p->fade_arrow_ul.color_fg == p->color_hvr_t )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTHOT;
			} else {
				state = n_ABS_UPHOT;
			}
		} else
		if ( p->fade_arrow_ul.color_fg == p->color_hvr_s )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTHOT;
			} else {
				state = n_ABS_UPHOT;
			}
		}

		if ( p->enabled_ul == n_posix_false )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_LEFTDISABLED;
			} else {
				state = n_ABS_UPDISABLED;
			}
		}

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		n_bmp bmp_t; n_bmp_zero( &bmp_t ); n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_t );


		n_type_real ratio = (n_type_real) p->fade_arrow_ul.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_free_fast( &p->bmp_ul );
		n_bmp_alias( &bmp_t, &p->bmp_ul );
		n_bmp_free_fast( &bmp_f );


		n_gdi_doublebuffer_cleanup( &n_gdi_doublebuffer_instance );


		if ( n_win_darkmode_onoff )
		{
			n_win_darkmode_bmp_flush_reverse( &p->bmp_ul );
			if ( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE )
			{
				n_win_scrollbar_flush_mixer( &p->bmp_ul, n_bmp_white, N_WIN_SCROLLBAR_BLEND );
			}
		}

	}


	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		//

	} else {

		n_type_gfx sx = (n_type_gfx) p->rect_arrow_dr.sx;
		n_type_gfx sy = (n_type_gfx) p->rect_arrow_dr.sy;
//if ( n_win_scrollbar_debug_instance == p ) { n_posix_debug_literal( "%d %d", sx,sy ); }

		RECT rect = { 0,0,sx,sy };


		HDC hdc = n_gdi_doublebuffer_simple_init( p->hwnd, sx,sy );


		int part  = 0;
		int state = 0;


		if ( p->fade_arrow_dr.color_bg == p->color_arbtn )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTNORMAL;
			} else {
				state = n_ABS_DOWNNORMAL;
			}
		} else
		if ( p->fade_arrow_dr.color_bg == p->color_press )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTPRESSED;
			} else {
				state = n_ABS_DOWNPRESSED;
			}
		} else
		if ( p->fade_arrow_dr.color_bg == p->color_hvr_t )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTHOT;
			} else {
				state = n_ABS_DOWNHOT;
			}
		} else
		if ( p->fade_arrow_dr.color_bg == p->color_hvr_s )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTHOT;
			} else {
				state = n_ABS_DOWNHOT;
			}
		}

		if ( p->enabled_dr == n_posix_false )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTDISABLED;
			} else {
				state = n_ABS_DOWNDISABLED;
			}
		}

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		n_bmp bmp_f; n_bmp_zero( &bmp_f ); n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_f );


		if ( p->fade_arrow_dr.color_fg == p->color_arbtn )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTNORMAL;
			} else {
				state = n_ABS_DOWNNORMAL;
			}
		} else
		if ( p->fade_arrow_dr.color_fg == p->color_press )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTPRESSED;
			} else {
				state = n_ABS_DOWNPRESSED;
			}
		} else
		if ( p->fade_arrow_dr.color_fg == p->color_hvr_t )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTHOT;
			} else {
				state = n_ABS_DOWNHOT;
			}
		} else
		if ( p->fade_arrow_dr.color_fg == p->color_hvr_s )
		{
			part  = n_SBP_ARROWBTN;
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTHOT;
			} else {
				state = n_ABS_DOWNHOT;
			}
		}

		if ( p->enabled_dr == n_posix_false )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				state = n_ABS_RIGHTDISABLED;
			} else {
				state = n_ABS_DOWNDISABLED;
			}
		}

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		n_bmp bmp_t; n_bmp_zero( &bmp_t ); n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_t );


		n_type_real ratio = (n_type_real) p->fade_arrow_dr.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_free_fast( &p->bmp_dr );
		n_bmp_alias( &bmp_t, &p->bmp_dr );
		n_bmp_free_fast( &bmp_f );


		n_gdi_doublebuffer_cleanup( &n_gdi_doublebuffer_instance );


		if ( n_win_darkmode_onoff )
		{
			n_win_darkmode_bmp_flush_reverse( &p->bmp_dr );
			if ( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE )
			{
				n_win_scrollbar_flush_mixer( &p->bmp_dr, n_bmp_white, N_WIN_SCROLLBAR_BLEND );
			}
		}

	}


	// Thumb

	{

		n_type_gfx sx;
		n_type_gfx sy;

		if ( ( p->option & N_WIN_SCROLLBAR_OPTION_DRAW_100PC )&&( p->enabled == n_posix_false ) )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				sx = p->sx;
				sy = (n_type_gfx) p->pixel_minim;
			} else {
				sx = (n_type_gfx) p->pixel_minim;
				sy = p->sy;
			}
		} else {
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				sx = (n_type_gfx) p->pixel_thumb;
				sy = (n_type_gfx) p->pixel_minim;
			} else {
				sx = (n_type_gfx) p->pixel_minim;
				sy = (n_type_gfx) p->pixel_thumb;
			}
		}

		RECT rect = { 0,0,sx,sy };


		HDC hdc = n_gdi_doublebuffer_simple_init( p->hwnd, sx,sy );


		int part  = 0;
		int state = 0;

		int part_thumb;
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			part_thumb = n_SBP_THUMBBTNHORZ;
		} else {
			part_thumb = n_SBP_THUMBBTNVERT;
		}

		if ( p->fade_thumb.color_bg == p->color_thumb )
		{
			part  = part_thumb;
			state = n_SCRBS_NORMAL;
		} else
		if ( p->fade_thumb.color_bg == p->color_press )
		{
			part  = part_thumb;
			state = n_SCRBS_PRESSED;
		} else
		if ( p->fade_thumb.color_bg == p->color_hvr_t )
		{
			part  = part_thumb;
			state = n_SCRBS_HOT;
		} else
		if ( p->fade_thumb.color_bg == p->color_hvr_s )
		{
			part  = part_thumb;
			state = n_SCRBS_HOVER;
		}

		n_bmp bmp_f; n_bmp_zero( &bmp_f );

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		// Grip : not used in Win8 or later

		// [!] : IE uses always, Scroll Bar Control uses when not minimum size

		if ( n_posix_false == n_win_scrollbar_is_thumb_minimal( p ) )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				part = n_SBP_GRIPPERHORZ;
			} else {
				part = n_SBP_GRIPPERVERT;
			}
			uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );
		}

		n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_f );


		if ( p->fade_thumb.color_fg == p->color_thumb )
		{
			part  = part_thumb;
			state = n_SCRBS_NORMAL;
		} else
		if ( p->fade_thumb.color_fg == p->color_press )
		{
			part  = part_thumb;
			state = n_SCRBS_PRESSED;
		} else
		if ( p->fade_thumb.color_fg == p->color_hvr_t )
		{
			part  = part_thumb;
			state = n_SCRBS_HOT;
		} else
		if ( p->fade_thumb.color_fg == p->color_hvr_s )
		{
			part  = part_thumb;
			state = n_SCRBS_HOVER;
		}

		n_bmp bmp_t; n_bmp_zero( &bmp_t );

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );

		// Grip : not used in Win8 or later

		if ( n_posix_false == n_win_scrollbar_is_thumb_minimal( p ) )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				part = n_SBP_GRIPPERHORZ;
			} else {
				part = n_SBP_GRIPPERVERT;
			}
			uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );
		}

		n_bmp_carboncopy( &n_gdi_doublebuffer_instance.bmp, &bmp_t );


		n_type_real ratio = (n_type_real) p->fade_thumb.percent * 0.01;
		n_bmp_flush_blendcopy( &bmp_f, &bmp_t, ratio );


		n_bmp_free_fast( &p->bmp_th );
		n_bmp_alias( &bmp_t, &p->bmp_th );
		n_bmp_free_fast( &bmp_f );

		n_gdi_doublebuffer_cleanup( &n_gdi_doublebuffer_instance );


		if ( n_win_darkmode_onoff )
		{
			n_win_darkmode_bmp_flush_reverse( &p->bmp_th );
			if ( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE )
			{
				n_win_scrollbar_flush_mixer( &p->bmp_th, n_bmp_white, N_WIN_SCROLLBAR_BLEND_THUMB );
			}
		}

	}


	n_uxtheme_exit( &uxtheme, p->hwnd );


	return n_posix_true;
}

void
n_win_scrollbar_ui_shaft( n_win_scrollbar *p )
{

	n_type_gfx o_x = 0;
	n_type_gfx o_y = 0;
	n_type_gfx osx = p->sx;
	n_type_gfx osy = p->sy;

	n_bmp_new_fast( &p->bmp_sh, osx,osy );

	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC      )
	{

		u32 color_hatch = n_bmp_white;
		if ( n_win_darkmode_onoff ) { color_hatch = n_win_darkmode_bg_argb; }

		n_bmp_box                  ( &p->bmp_sh, o_x,o_y,osx,osy, p->color_shaft );
		n_win_scrollbar_bmp_checker( &p->bmp_sh, o_x,o_y,osx,osy,    color_hatch );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{

		u32 color_hatch = n_bmp_white;
		if ( n_win_darkmode_onoff ) { color_hatch = n_win_darkmode_bg_argb; }

		n_bmp_box                  ( &p->bmp_sh, o_x,o_y,osx,osy, p->color_shaft );
		n_win_scrollbar_bmp_checker( &p->bmp_sh, o_x,o_y,osx,osy,    color_hatch );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_SOLID        )
	{

		n_bmp_box( &p->bmp_sh, o_x+0,o_y+0,osx   ,osy   , p->color_shaft );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI    )
	{

		n_bmp_box( &p->bmp_sh, o_x+0,o_y+0,osx   ,osy   , p->color_shaft );
/*
		n_type_gfx round = n_win_fluent_ui_round_param( p->hwnd );

		if ( p->bmp_parent == NULL )
		{
			n_bmp_box( &p->bmp_sh,         0,        0,round,round, p->color_edge_ul );
			n_bmp_box( &p->bmp_sh, osx-round,        0,round,round, p->color_edge_ur );
			n_bmp_box( &p->bmp_sh,         0,osy-round,round,round, p->color_edge_dl );
			n_bmp_box( &p->bmp_sh, osx-round,osy-round,round,round, p->color_edge_dr );
		}

		n_bmp_roundrect_pixel( &p->bmp_sh, o_x+0,o_y+0,osx   ,osy   , p->color_shaft, round );
*/
//n_bmp_save_literal( &p->bmp_sh, "ret.bmp" );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE  )
	{

		n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
		n_uxtheme_init( &uxtheme, p->hwnd, L"SCROLLBAR" );


		HDC hdc = n_gdi_doublebuffer_simple_init( p->hwnd, osx,osy );


		int part  = 0;
		int state = 0;

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			part = n_SBP_LOWERTRACKHORZ;
		} else {
			part = n_SBP_LOWERTRACKVERT;
		}

		RECT rect = { o_x,o_y,osx,osy };
		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &rect, NULL );


		n_bmp_flush_fastcopy( &n_gdi_doublebuffer_instance.bmp, &p->bmp_sh );


		n_gdi_doublebuffer_cleanup( &n_gdi_doublebuffer_instance );


		if ( n_win_darkmode_onoff )
		{
			n_win_darkmode_bmp_flush_reverse( &p->bmp_sh );
			if ( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE )
			{
				n_win_scrollbar_flush_mixer( &p->bmp_sh, n_bmp_white, N_WIN_SCROLLBAR_BLEND );
			}
		}


		n_uxtheme_exit( &uxtheme, p->hwnd );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE      )
	{

		n_bmp_box( &p->bmp_sh, o_x+0,o_y+0,osx   ,osy   , p->color_shaft );

	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{

		n_gdi gdi; n_gdi_zero( &gdi );

		gdi.sx            = osx;
		gdi.sy            = osy;
		gdi.style         = N_GDI_DEFAULT;
		gdi.base_style    = p->stripe_type;
		gdi.base_color_fg = p->color_shaft;
		gdi.base_color_bg = p->color_trans;

		n_gdi_bmp( &gdi, &p->bmp_sh );

	}


	// [!] : for collision/hittest

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		o_x += (n_type_gfx) p->rect_main.x;
		o_y += (n_type_gfx) p->rect_main.y;
	}

	n_win_scrollbar_rect_set( &p->rect_shaft, o_x,o_y,osx,osy );


	return;
}

void
n_win_scrollbar_ui( n_win_scrollbar *p )
{

	if ( p->init_onoff == n_posix_false ) { return; }


	// Global

	n_posix_bool p_no_round = n_game_progressbar_no_round; 
	n_type_gfx   p_border   = n_game_progressbar_border;
	n_type_gfx   p_div      = n_game_progressbar_round_div;

	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		n_game_progressbar_no_round  = n_posix_true;
		n_game_progressbar_border    = p->scale;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{
		n_game_progressbar_no_round  = n_posix_false;
		n_game_progressbar_border    = p->scale;
		n_game_progressbar_round_div = 4;
	}


	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->stripe_type = N_GDI_BASE_PROGRESS_H;
	} else {
		p->stripe_type = N_GDI_BASE_PROGRESS_V;
	}


	// Shaft

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DWM_ON )
	{
		//
	} else {
		if ( NULL == N_BMP_PTR( &p->bmp_sh ) )
		{
			n_win_scrollbar_ui_shaft( p );
		}
	}


	// Main

	if ( n_win_scrollbar_ui_uxtheme( p ) )
	{

		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
		{
			n_game_progressbar_no_round  = p_no_round;
			n_game_progressbar_border    = p_border;
			n_game_progressbar_round_div = p_div;
		} else
		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
		{
			n_game_progressbar_no_round  = p_no_round;
			n_game_progressbar_border    = p_border;
			n_game_progressbar_round_div = p_div;
		}

		return;
	}


	n_gdi gdi; n_gdi_zero( &gdi );


	gdi.sx                  = (n_type_gfx) p->pixel_arrow_sx;
	gdi.sy                  = (n_type_gfx) p->pixel_arrow_sy;
	gdi.scale               = p->scale;//N_GDI_SCALE_AUTO;
	gdi.style               = N_GDI_DEFAULT;
	gdi.layout              = N_GDI_LAYOUT_HORIZONTAL;
	gdi.align               = N_GDI_ALIGN_CENTER;

	gdi.base_color_bg       = p->color_shaft;
	gdi.base_style          = N_GDI_BASE_SOLID;
	gdi.base_unit           = 0;

	gdi.text_font           = n_posix_literal( "Marlett" );
	gdi.text_size           = (n_type_gfx) ( p->pixel_minim / 3 * 2 );
	gdi.text_style          = N_GDI_TEXT_SMOOTH;
	gdi.text_color_main     = p->color_arrow;

	gdi.percent             = 100;


	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		gdi.text_font  = n_gdi_font_find( n_posix_literal( "MS UI Gothic" ), n_posix_literal( "Small Fonts" ) );
		gdi.text_style = gdi.text_style | N_GDI_TEXT_BOLD;

		//gdi.text_size  = p->pixel_minim;

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
		{
			n_type_gfx tmp_sx = gdi.sx;
			           gdi.sx = gdi.sy;
			           gdi.sy = tmp_sx;
		}
	}


	int frame_style_thumb = N_GDI_FRAME_NOFRAME;
	int frame_style_arrow = N_GDI_FRAME_NOFRAME;

	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC      )
	{
		frame_style_thumb = N_GDI_FRAME_SCROLLARROW;
		frame_style_arrow = N_GDI_FRAME_SCROLLARROW;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{
		frame_style_thumb = N_GDI_FRAME_FLAT;
		frame_style_arrow = N_GDI_FRAME_FLAT;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_SOLID        )
	{
		frame_style_thumb = N_GDI_FRAME_NOFRAME;
		frame_style_arrow = N_GDI_FRAME_NOFRAME;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI    )
	{
		frame_style_thumb = N_GDI_FRAME_NOFRAME;
		frame_style_arrow = N_GDI_FRAME_NOFRAME;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		frame_style_thumb = N_GDI_FRAME_NOFRAME;
		frame_style_arrow = N_GDI_FRAME_NOFRAME;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		frame_style_thumb = N_GDI_FRAME_NOFRAME;
		frame_style_arrow = N_GDI_FRAME_NOFRAME;
	}


	n_posix_char str[ 2 ];
	gdi.text = str;

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		//

	} else {

		// Arrow : Up / Left

		gdi.frame_style   = frame_style_arrow;

		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
		{
			gdi.style         = N_GDI_DEFAULT;
			gdi.base_style    = p->stripe_type;
			gdi.base_color_fg = p->fade_color_arrow_ul;
			gdi.base_color_bg = p->fade_color_arrow_ul;
		} else
		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
		{
			gdi.style         = N_GDI_DEFAULT;
			gdi.base_style    = p->stripe_type;
			gdi.base_color_fg = p->fade_color_arrow_ul;
			gdi.base_color_bg = p->color_trans;
		} else {
			gdi.style         = N_GDI_SYSTEMCOLOR;
			gdi.base_color_fg = p->fade_color_arrow_ul;
			gdi.base_color_bg = p->fade_color_arrow_ul;
		}

		if ( p->pressed_arrow_ul )
		{
			gdi.style |= N_GDI_PRESSED;
		}

		if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				str[ 0 ] = n_posix_literal( '<' );
				str[ 1 ] = 0x00;
			} else {
				str[ 0 ] = n_posix_literal( '<' );
				str[ 1 ] = 0x00;
			}
		} else {
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				str[ 0 ] = 0x33;
				str[ 1 ] = 0x00;
			} else {
				str[ 0 ] = 0x35;
				str[ 1 ] = 0x00;
			}
		}


		if ( NULL == N_BMP_PTR( &p->bmp_ul ) )
		{
			n_gdi_bmp( &gdi, &p->bmp_ul );
			if ( p->enabled_ul == n_posix_false ) { n_win_scrollbar_flush_mixer( &p->bmp_ul, p->color_shaft, 0.5 ); }

			if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
			{
				if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
				{
					n_bmp_rotate( &p->bmp_ul, N_BMP_ROTATE_RIGHT );
				}
			}
		}


		// Arrow : Down / Right

		gdi.frame_style   = frame_style_arrow;

		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
		{
			gdi.style         = N_GDI_DEFAULT;
			gdi.base_style    = p->stripe_type;
			gdi.base_color_fg = p->fade_color_arrow_dr;
			gdi.base_color_bg = p->fade_color_arrow_dr;
		} else
		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
		{
			gdi.style         = N_GDI_DEFAULT;
			gdi.base_style    = p->stripe_type;
			gdi.base_color_fg = p->fade_color_arrow_dr;
			gdi.base_color_bg = p->color_trans;
		} else {
			gdi.style         = N_GDI_SYSTEMCOLOR;
			gdi.base_color_fg = p->fade_color_arrow_dr;
			gdi.base_color_bg = p->fade_color_arrow_dr;
		}

		if ( p->pressed_arrow_dr )
		{
			gdi.style |= N_GDI_PRESSED;
		}

		if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				str[ 0 ] = n_posix_literal( '>' );
				str[ 1 ] = 0x00;
			} else {
				str[ 0 ] = n_posix_literal( '>' );
				str[ 1 ] = 0x00;
			}
		} else {
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				str[ 0 ] = 0x34;
				str[ 1 ] = 0x00;
			} else {
				str[ 0 ] = 0x36;
				str[ 1 ] = 0x00;
			}
		}

		if ( NULL == N_BMP_PTR( &p->bmp_dr ) )
		{
			n_gdi_bmp( &gdi, &p->bmp_dr );
			if ( p->enabled_dr == n_posix_false ) { n_win_scrollbar_flush_mixer( &p->bmp_dr, p->color_shaft, 0.5 ); }

			if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
			{
				if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
				{
					n_bmp_rotate( &p->bmp_dr, N_BMP_ROTATE_RIGHT );
				}
			}
		}

	}


	// Thumb

	gdi.frame_style   = frame_style_thumb;

	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		gdi.style         = N_GDI_DEFAULT;
		gdi.base_style    = p->stripe_type;
		gdi.base_color_fg = p->fade_color_thumb;
		gdi.base_color_bg = p->fade_color_thumb;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{
		gdi.style         = N_GDI_DEFAULT;
		gdi.base_style    = p->stripe_type;
		gdi.base_color_fg = p->fade_color_thumb;
		gdi.base_color_bg = n_bmp_alpha_replace_pixel( p->color_shaft, 0 );
	} else {
		gdi.style         = N_GDI_SYSTEMCOLOR;
		gdi.base_style    = N_GDI_BASE_SOLID;
		gdi.base_color_fg = p->fade_color_thumb;
		gdi.base_color_bg = p->fade_color_thumb;
	}

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		str[ 0 ] = 0x00;
		gdi.sx   = (n_type_gfx) p->pixel_thumb;
		gdi.sy   = (n_type_gfx) p->pixel_minim;
	} else {
		str[ 0 ] = 0x00;
		gdi.sx   = (n_type_gfx) p->pixel_minim;
		gdi.sy   = (n_type_gfx) p->pixel_thumb;
	}

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DRAW_100PC )
	{
		if ( p->enabled == n_posix_false )
		{
			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				gdi.sx = p->sx;
			} else {
				gdi.sy = p->sy;
			}
		}
	}

	if ( NULL == N_BMP_PTR( &p->bmp_th ) )
	{
		if ( ( p->enabled )||( p->option & N_WIN_SCROLLBAR_OPTION_DRAW_100PC ) )
		{
			if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
			{
				n_bmp_new_fast( &p->bmp_th, gdi.sx, gdi.sy );
				n_bmp_flush( &p->bmp_th, p->color_shaft );

				n_type_gfx round = n_win_fluent_ui_round_param( p->hwnd );
				n_bmp_roundrect_pixel( &p->bmp_th, 0,0,gdi.sx,gdi.sy, p->fade_color_thumb, round );
			} else {
				n_gdi_bmp( &gdi, &p->bmp_th );
				n_win_scrollbar_bmp_alpha_partially_visible( &p->bmp_th );
//n_bmp_save_literal( &p->bmp_th, "ret.bmp" );
			}
		}
	}


	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		n_game_progressbar_no_round  = p_no_round;
		n_game_progressbar_border    = p_border;
		n_game_progressbar_round_div = p_div;
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{
		n_game_progressbar_no_round  = p_no_round;
		n_game_progressbar_border    = p_border;
		n_game_progressbar_round_div = p_div;
	}


	return;
}




#define n_win_scrollbar_zero( p ) n_memory_zero( p, sizeof( n_win_scrollbar ) )

void
n_win_scrollbar_refresh_redraw_area( n_win_scrollbar *p )
{

	p->redraw_x  = 0;
	p->redraw_y  = 0;
	p->redraw_sx = p->sx;
	p->redraw_sy = p->sy;


	return;
}

void
n_win_scrollbar_refresh_cache( n_win_scrollbar *p )
{

	n_bmp_free( &p->bmp_sh );
	n_bmp_free( &p->bmp_ul );
	n_bmp_free( &p->bmp_dr );
	n_bmp_free( &p->bmp_th );
	n_bmp_free( &p->bmp_gr );


	return;
}

void
n_win_scrollbar_refresh( n_win_scrollbar *p )
{
//n_win_scrollbar_debug_count( p );

	n_win_scrollbar_refresh_redraw_area( p );

	n_win_scrollbar_refresh_cache( p );

	extern n_posix_bool n_win_scrollbar_scroll_unit( n_win_scrollbar *p, n_type_real, int );
	n_type_real  pos = p->unit_pos;
	p->unit_pos = 0;
	n_win_scrollbar_scroll_unit( p, pos, N_WIN_SCROLLBAR_SCROLL_SEND );

	extern void n_win_scrollbar_draw_always( n_win_scrollbar *p, n_posix_bool );
	n_win_scrollbar_draw_always( p, n_posix_true );

	p->fade_thumb.stop = n_posix_false;


	return;
}

void
n_win_scrollbar_callback( void *data )
{

	n_win_scrollbar *p = data;

	n_win_scrollbar_refresh( p );


	return;
}

n_type_real
n_win_scrollbar_position_unit2pixel( n_win_scrollbar *p )
{
	return ( p->unit_pos / p->unit_max ) * p->pixel_max;
}

n_type_real
n_win_scrollbar_position_pixel2unit( n_win_scrollbar *p )
{
	return ( p->pixel_pos / p->pixel_max ) * p->unit_max;
}

n_type_real
n_win_scrollbar_position_last_unit( n_win_scrollbar *p )
{
	return p->unit_max - p->unit_page;
}

n_type_real
n_win_scrollbar_position_last_pixel( n_win_scrollbar *p )
{
	return p->pixel_max - p->pixel_page;
}

void
n_win_scrollbar_position_cursor( n_win_scrollbar *p, n_type_gfx *x, n_type_gfx *y )
{

	n_type_gfx cur_x, cur_y; n_win_cursor_position_relative( p->hwnd, &cur_x, &cur_y );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			cur_x -= (n_type_gfx) p->rect_main.x;
		} else {
			cur_y -= (n_type_gfx) p->rect_main.y;
		}

	}

	if ( x != NULL ) { (*x) = cur_x; }
	if ( y != NULL ) { (*y) = cur_y; }


	return;
}

void
n_win_scrollbar_position_thumb( n_win_scrollbar *p, n_type_real *x, n_type_real *y )
{

	n_type_real dx = 0;
	n_type_real dy = 0;


	// [!] : thumb position

	if ( p->drag_onoff )
	{

		// [Needed] : prv only

		//n_win_scrollbar_position_cursor( p, &p->cur_cursor_x, &p->cur_cursor_y );

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			dx = p->prv_cursor_x - p->pixel_arrow_sx - p->pixel_offset;
		} else {
			dy = p->prv_cursor_y - p->pixel_arrow_sy - p->pixel_offset;
		}

	} else {

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			dx = p->pixel_pos;
		} else {
			dy = p->pixel_pos;
		}

	}


	// [!] : clamper

	n_type_real d = 0;
	if ( p->option & N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX ) { d = p->pixel_patch; }

	n_type_real pixel_last = n_win_scrollbar_position_last_pixel( p ) - d;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		dx = n_posix_minmax_n_type_real( 0, pixel_last, dx );
	} else {
		dy = n_posix_minmax_n_type_real( 0, pixel_last, dy );
	}


	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_pos = dx;
	} else {
		p->pixel_pos = dy;
	}


	// [!] : write back

	if ( x != NULL ) { (*x) = dx; }
	if ( y != NULL ) { (*y) = dy; }


	return;
}

void
n_win_scrollbar_bulk_fade_init( n_win_scrollbar *p )
{

	// [x] : N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND : initial color will be inaccurate

	n_bmp_fade_init( &p->fade_thumb   , p->color_thumb );
	n_bmp_fade_init( &p->fade_arrow_ul, p->color_arbtn );
	n_bmp_fade_init( &p->fade_arrow_dr, p->color_arbtn );


	return;
}

void
n_win_scrollbar_arrowbutton_onoff( n_win_scrollbar *p, n_type_real f, n_type_real t, n_type_real pos )
{
//n_win_scrollbar_hwndprintf_literal( p, " %g %g %g ", t, pos, pos + p->pixel_step );
//n_win_scrollbar_hwndprintf_literal( p, " %g ", p->pixel_step );

	if ( p->enabled )
	{

		n_posix_bool p_enabled_ul = p->enabled_ul;
		n_posix_bool p_enabled_dr = p->enabled_dr;

		n_type_real delta_f = fabs( pos - f );
		n_type_real delta_t = fabs( pos - t );
//n_win_scrollbar_hwndprintf_literal( p, " %f %f %f ", f, t, pos );
//n_win_scrollbar_hwndprintf_literal( p, " %f %.30f ", delta_f, delta_t );

		// [!] : delta will be non-zero value

		if ( delta_f < 0.0000000001 ) { p->enabled_ul = n_posix_false; } else { p->enabled_ul = n_posix_true; }
		if ( delta_t < 0.0000000001 ) { p->enabled_dr = n_posix_false; } else { p->enabled_dr = n_posix_true; }

//n_win_scrollbar_hwndprintf_literal( p, " %f %f ", delta_f, p->pixel_step );
		if ( delta_f < p->pixel_step )
		{
			p->enabled_ul = n_posix_false;

			if ( p->option & N_WIN_SCROLLBAR_OPTION_CLAMP_BIG_THUMB )
			{
				p->unit_pos = 0;
			}
		}

		if ( p->init_onoff )
		{
			p_enabled_ul = p->enabled_ul + 1;
			p_enabled_dr = p->enabled_dr + 1;
		}

		if ( p_enabled_ul != p->enabled_ul ) { n_bmp_free( &p->bmp_ul ); }
		if ( p_enabled_dr != p->enabled_dr ) { n_bmp_free( &p->bmp_dr ); }

	}


	return;
}

static n_posix_bool n_win_scrollbar_on_settingchange_color_dwm_window = n_posix_true;

void
n_win_scrollbar_on_settingchange( n_win_scrollbar *p, n_posix_bool auto_style, n_posix_bool redraw )
{

	p->fade_onoff  = n_win_fade_is_on();

	p->scale       = (n_type_gfx) trunc( n_win_scale( p->hwnd ) );


	if (
		( p->style == N_WIN_SCROLLBAR_STYLE_AUTO )
		||
		( auto_style )
	)
	{
		if ( n_win_fluent_ui_onoff == N_WIN_FLUENT_UI_OVERRIDE )
		{
			p->style = N_WIN_SCROLLBAR_STYLE_FLUENT_UI;
		} else
		if ( n_win_style_is_classic() )
		{
			p->style = N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT;
		} else {
			if ( n_win_fluent_ui_onoff )
			{
				if ( p->win8_onoff )
				{
					p->style = N_WIN_SCROLLBAR_STYLE_FLUENT_UI;
				} else {
					p->style = N_WIN_SCROLLBAR_STYLE_VISUALSTYLE;
				}
			} else {
				p->style = N_WIN_SCROLLBAR_STYLE_VISUALSTYLE;
			}
		}
	}
//p->style = N_WIN_SCROLLBAR_STYLE_SOLID;


	p->color_trans = n_bmp_white_invisible;
	p->color__back = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE    );
	p->color_arbtn = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE    );
	p->color_thumb = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE    );
	p->color_bordr = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE    );
	p->color_shaft = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
	p->color_press = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW  );
	p->color_hvr_t = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
	p->color_hvr_s = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.25 );
	p->color_arrow = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNTEXT    );

	p->color_edge_ul = p->color__back;
	p->color_edge_ur = p->color__back;
	p->color_edge_dl = p->color__back;
	p->color_edge_dr = p->color__back;

	if ( n_win_darkmode_onoff )
	{
		p->color_arrow = n_bmp_white;
	}

	if (
		( n_win_darkmode_onoff )
		&&
		( p->style != N_WIN_SCROLLBAR_STYLE_STRIPE       )
		&&
		( p->style != N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	)
	{
		p->color_arbtn = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.33 );
		p->color_thumb = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.33 );
		p->color_shaft = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.25 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.05 );
		p->color_hvr_t = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.33 );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.22 );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_CLASSIC_FLAT )
	{
		p->color_shaft = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE  );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_SOLID        )
	{
		p->color_shaft = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE  );
		p->color_hvr_t = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_3DSHADOW );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.25 );
		p->color_arbtn = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_thumb = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb,    n_bmp_black, 0.50 );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI    )
	{
		p->color_shaft = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNFACE  );
		p->color_shaft = n_bmp_blend_pixel( p->color_shaft, n_bmp_black, 0.05 );
		p->color_hvr_t = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_3DSHADOW );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.25 );
		p->color_arbtn = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_thumb = n_bmp_blend_pixel( p->color_hvr_t, p->color_shaft, 0.50 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb,    n_bmp_black, 0.50 );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE       )
	{
		u32 color_window;
		if ( n_win_scrollbar_on_settingchange_color_dwm_window )
		{
			color_window = n_win_dwm_windowcolor_arranged();
		} else {
			color_window = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_HIGHLIGHT );
		}
		p->color_arbtn = n_bmp_lightness_replace_pixel( color_window, 100 );
		p->color_thumb = n_bmp_lightness_replace_pixel( color_window, 100 );
		p->color_hvr_t = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.25 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.50 );
		p->color_arrow = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.50 );
	} else
	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{
		u32 color_window;
		if ( n_win_scrollbar_on_settingchange_color_dwm_window )
		{
			color_window = n_win_dwm_windowcolor_arranged();
		} else {
			color_window = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_HIGHLIGHT );
		}
		p->color_arbtn = n_bmp_lightness_replace_pixel( color_window, 100 );
		p->color_thumb = n_bmp_lightness_replace_pixel( color_window, 100 );
		p->color_hvr_t = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.50 );
		p->color_hvr_s = n_bmp_blend_pixel( p->color_thumb, n_bmp_white, 0.25 );
		p->color_press = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.50 );
		p->color_arrow = n_bmp_blend_pixel( p->color_thumb, n_bmp_black, 0.50 );
	}

	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI    )
	{
		p->color_arbtn = p->color_shaft;
	}

	if ( p->color_thumb == n_bmp_trans ) { p->color_thumb = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_bordr == n_bmp_trans ) { p->color_bordr = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_shaft == n_bmp_trans ) { p->color_shaft = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_press == n_bmp_trans ) { p->color_press = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_hvr_t == n_bmp_trans ) { p->color_hvr_t = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_hvr_s == n_bmp_trans ) { p->color_hvr_s = n_bmp_rgb( 1,1,1 ); }
	if ( p->color_arrow == n_bmp_trans ) { p->color_arrow = n_bmp_rgb( 1,1,1 ); }

	if ( 32 != n_win_desktop_bpp() )
	{
		p->color_thumb = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_thumb ) );
		p->color_bordr = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_bordr ) );
		p->color_shaft = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_shaft ) );
		p->color_press = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_press ) );
		p->color_hvr_t = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_hvr_t ) );
		p->color_hvr_s = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_hvr_s ) );
		p->color_arrow = n_gdi_colorref2argb( p->hwnd, n_bmp_argb2colorref( p->color_arrow ) );
	}

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		p->color_thumb = n_bmp_alpha_visible_pixel( p->color_thumb );
		p->color_bordr = n_bmp_alpha_visible_pixel( p->color_bordr );
		p->color_shaft = n_bmp_alpha_visible_pixel( p->color_shaft );
		p->color_press = n_bmp_alpha_visible_pixel( p->color_press );
		p->color_hvr_t = n_bmp_alpha_visible_pixel( p->color_hvr_t );
		p->color_hvr_s = n_bmp_alpha_visible_pixel( p->color_hvr_s );
		p->color_arrow = n_bmp_alpha_visible_pixel( p->color_arrow );
	}

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DWM_ON )
	{
		p->color_trans = 0;
	}


	n_win_scrollbar_bulk_fade_init( p );


	// [Needed] : for initial arrow button size

	extern void n_win_scrollbar_metrics( n_win_scrollbar* );
	n_win_scrollbar_metrics( p );


	if ( redraw ) { n_win_scrollbar_refresh( p ); }


	return;
}

void
n_win_scrollbar_init( n_win_scrollbar *p, HWND hwnd_parent, int layout, int style, int option )
{

	n_win_scrollbar_zero( p );


	//n_gdiplus_init();


	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		p->hwnd        = hwnd_parent;
		p->hwnd_parent = hwnd_parent;
	} else {
		p->hwnd_parent = hwnd_parent;
		n_win_gui_literal( hwnd_parent, N_WIN_GUI_CANVAS, "", &p->hwnd );
	}


	p->layout     = layout;
	p->style      = style;
	p->option     = option;

	p->win8_onoff = n_sysinfo_version_8_or_later();
	p->show_onoff = n_posix_true;


	// [x] : memory leak

	n_win_simplemenu_init( &p->menu );

	p->menu.callback_data = (void*) p;
	p->menu.callback      = n_win_scrollbar_callback;

	n_win_simplemenu_set( &p->menu, 0, NULL, n_posix_literal( "[ ]Scroll Here" ), NULL );
	n_win_simplemenu_set( &p->menu, 1, NULL, n_posix_literal( "[-]"            ), NULL );
	n_win_simplemenu_set( &p->menu, 2, NULL, n_posix_literal( "[ ]Min"         ), NULL );
	n_win_simplemenu_set( &p->menu, 3, NULL, n_posix_literal( "[ ]Max"         ), NULL );


	if ( p->timer_id == 0 ) { p->timer_id = n_win_timer_id_get(); }
	n_win_timer_init( p->hwnd_parent, p->timer_id, N_WIN_SCROLLBAR_INTERVAL_EVENT );


	n_win_scrollbar_on_settingchange( p, ( style & N_WIN_SCROLLBAR_STYLE_AUTO ), n_posix_false );


	p->drag_clamp = n_posix_true;


	return;
}

void
n_win_scrollbar_exit( n_win_scrollbar *p )
{

	n_win_simplemenu_exit( &p->menu );

	n_win_timer_exit( p->hwnd_parent, p->timer_id );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		//
	} else {
		DestroyWindow( p->hwnd );
	}

	n_bmp_free_fast( &p->bmp_sh );
	n_bmp_free_fast( &p->bmp_ul );
	n_bmp_free_fast( &p->bmp_dr );
	n_bmp_free_fast( &p->bmp_th );
	n_bmp_free_fast( &p->bmp_gr );


	n_bmp_free_fast( &p->bmp_mainbuffer );


	//n_gdiplus_exit();


	n_win_scrollbar_zero( p );


	return;
}

n_type_gfx
n_win_scrollbar_stdsize( n_win_scrollbar *p )
{

	n_type_gfx ret;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		ret = GetSystemMetrics( SM_CYHSCROLL );
	} else {
		ret = GetSystemMetrics( SM_CXVSCROLL );
	}

	return ret;
}

void
n_win_scrollbar_enable( n_win_scrollbar *p, n_posix_bool enable, n_posix_bool redraw )
{

	if ( enable )
	{
		p->enabled    = n_posix_true;
		p->enabled_ul = n_posix_true;
		p->enabled_dr = n_posix_true;
	} else {
		p->enabled    = n_posix_false;
		p->enabled_ul = n_posix_false;
		p->enabled_dr = n_posix_false;
	}

	if ( redraw ) { n_win_scrollbar_refresh( p ); }


	return;
}

void
n_win_scrollbar_show( n_win_scrollbar *p, n_posix_bool onoff )
{

	if ( onoff )
	{

		p->show_onoff = n_posix_true;

		if ( n_posix_false == ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER ) )
		{
			ShowWindow( p->hwnd, SW_NORMAL );
		}

	} else {

		p->show_onoff = n_posix_false;

		if ( n_posix_false == ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER ) )
		{
			ShowWindow( p->hwnd, SW_HIDE );
		}

	}


	return;
}

void
n_win_scrollbar_metrics( n_win_scrollbar *p )
{
//return;

	if ( p->init_onoff == n_posix_false ) { return; }


	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		p->sx = (n_type_gfx) p->rect_main.sx;
		p->sy = (n_type_gfx) p->rect_main.sy;
	} else {
		n_win_size_client( p->hwnd, &p->sx, &p->sy );
	}


	n_type_gfx ctl = n_win_scrollbar_stdsize( p );

	p->sx = n_posix_max_n_type_gfx( ctl, p->sx );
	p->sy = n_posix_max_n_type_gfx( ctl, p->sy );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			p->pixel_arrow_sx = p->pixel_arrow_sy = 0;
			p->pixel_minim = p->sy;
		} else {
			p->pixel_arrow_sx = p->pixel_arrow_sy = 0;
			p->pixel_minim = p->sx;
		}

	} else {

		n_type_real n = 1;
		if ( p->option & N_WIN_SCROLLBAR_OPTION_BIG_ARROWS )
		{
			n = 1.5;
		}

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			p->pixel_minim    = p->sy;
			p->pixel_arrow_sx = (n_type_real) p->sy * n;
			p->pixel_arrow_sy = p->sy;
		} else {
			p->pixel_minim    = p->sx;
			p->pixel_arrow_sx = p->sx;
			p->pixel_arrow_sy = (n_type_real) p->sx * n;
		}

	}


	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_shaft = p->sx - ( p->pixel_arrow_sx * 2 );
	} else {
		p->pixel_shaft = p->sy - ( p->pixel_arrow_sy * 2 );
	}

	p->pixel_shaft = n_posix_max_n_type_real( p->pixel_minim, p->pixel_shaft );


	// [!] : the second mode

	p->unit_max   = p->unit_max_original;

	p->pixel_max  = n_posix_max_n_type_real( 1.0, p->pixel_shaft );
	p->pixel_step = ( p->unit_step / p->unit_max ) * p->pixel_max;
	p->pixel_page = ( p->unit_page / p->unit_max ) * p->pixel_max;
	p->pixel_pos  = ( p->unit_pos  / p->unit_max ) * p->pixel_max;
//n_win_scrollbar_hwndprintf_literal( p, " %g %g %g ", p->pixel_max, p->pixel_step, p->pixel_page );

	// [!] : minimum thumb size

	p->pixel_thumb_original = p->pixel_page;
	p->pixel_thumb          = n_posix_max_n_type_real( p->pixel_page, p->pixel_minim );

	// [Needed] : rounding is needed

	p->pixel_thumb_original = ceil( p->pixel_thumb_original );
	p->pixel_thumb          = ceil( p->pixel_thumb          );

//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " %g %g ", p->pixel_thumb_original, p->pixel_thumb ); }


	// [!] : the third mode

	if ( p->pixel_thumb_original < p->pixel_thumb )
	{
//n_win_scrollbar_debug_count( p );

//n_win_scrollbar_hwndprintf_literal( p, " %g %g ", (n_type_real) p->sy, (n_type_real) p->pixel_max );

		p->pixel_patch = ( p->pixel_max - p->pixel_page + p->pixel_thumb ) - p->pixel_max;

//n_win_scrollbar_hwndprintf_literal( p, " %g ", p->pixel_patch );

		if ( p->option & N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX )
		{
			n_type_real d = ( p->pixel_patch / ( p->pixel_max - p->pixel_patch ) ) * p->unit_max_original;
//n_win_scrollbar_hwndprintf_literal( p, " %g ", d );

//n_win_scrollbar_hwndprintf_literal( p, " %g %g %g ", p->unit_max_original, p->unit_step, p->unit_page );

			p->unit_max   = p->unit_max_original + d;
			p->pixel_step = ( p->unit_step / p->unit_max ) * p->pixel_max;
			p->pixel_page = ( p->unit_page / p->unit_max ) * p->pixel_max;
			p->pixel_pos  = ( p->unit_pos  / p->unit_max ) * p->pixel_max;

//n_win_scrollbar_hwndprintf_literal( p, " %g ", p->unit_max );
		} else {
			p->pixel_max  = n_posix_max_n_type_real( 1.0, p->pixel_max - p->pixel_patch );
			p->pixel_step = ( p->unit_step / p->unit_max ) * p->pixel_max;
			p->pixel_page = ( p->unit_page / p->unit_max ) * p->pixel_max;
			p->pixel_pos  = ( p->unit_pos  / p->unit_max ) * p->pixel_max;
		}

	} else {

		p->pixel_patch = 0;

	}


	return;
}

static n_posix_bool n_win_scrollbar_parameter_add_page = n_posix_true;

void
n_win_scrollbar_parameter( n_win_scrollbar *p, n_type_real step, n_type_real page, n_type_real max, n_type_real pos, n_posix_bool redraw )
{

	// [!] : the first mode

	if ( n_win_scrollbar_parameter_add_page ) { max += page; }

	p->unit_step = step;
	p->unit_page = page;
	p->unit_max  = n_posix_max_n_type_real( 1.0, max ) ;
	p->unit_pos  = pos;
//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " parameter() :  %g %g %g ", p->unit_pos, p->unit_page, p->unit_max ); }

	if ( max >= page )
	{
		p->enabled    = n_posix_true;
		p->enabled_ul = n_posix_true;
		p->enabled_dr = n_posix_true;
	} else {
		p->enabled    = n_posix_false;
		p->enabled_ul = n_posix_false;
		p->enabled_dr = n_posix_false;
	}

	p->unit_max_original = p->unit_max;


	if ( redraw )
	{
		n_win_scrollbar_refresh( p );
	}


	return;
}

n_posix_bool
n_win_scrollbar_scroll_pixel( n_win_scrollbar *p, n_type_real pixel_delta, int option )
{
//n_win_scrollbar_debug_count( p );

//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " n_win_scrollbar_scroll_pixel() " ); }


	if ( pixel_delta != 0 )
	{

		p->pixel_pos += pixel_delta;


		n_type_real pixel_min = 0;
		n_type_real pixel_max = n_win_scrollbar_position_last_pixel( p );

		n_type_real d = 0;
		if ( p->option & N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX ) { d = p->pixel_patch; }

		p->pixel_pos = n_posix_minmax_n_type_real( pixel_min, pixel_max - d, p->pixel_pos );
//n_win_scrollbar_hwndprintf_literal( p, " %f %f %f ", pixel_delta, p->pixel_pos, pixel_max );


		p->prev_pos = p->unit_pos;


		n_type_real unit_min = 0;
		n_type_real unit_max = n_win_scrollbar_position_last_unit( p );

		p->unit_pos = n_win_scrollbar_position_pixel2unit( p );

		if (
			( p->unit_pos > ( unit_max - p->unit_step ) )
			&&
			( p->unit_step > fabs( ceil( p->unit_pos ) - p->unit_pos ) )
		)
		{
			p->unit_pos = ceil( p->unit_pos );
		}

		p->unit_pos = n_posix_minmax_n_type_real( unit_min, unit_max, p->unit_pos );

//if ( p->layout == 0 ) { n_win_scrollbar_hwndprintf_literal( p, " %g %g ", p->unit_pos, prv_unit_pos ); }
//if ( p->layout == 0 ) { n_win_scrollbar_hwndprintf_literal( p, " %g %g ", p->unit_pos,     unit_max ); }

	}


	n_posix_bool ret = n_posix_false;
	if ( option == N_WIN_SCROLLBAR_SCROLL_NONE )
	{
		//
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_SEND )
	{
		n_win_message_send( p->hwnd_parent, WM_COMMAND, p->unit_pos, p->hwnd );
		ret = n_posix_true;
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_AUTO )
	{
		ret = ( p->prev_pos != p->unit_pos );
		if ( ret )
		{
			n_win_message_send( p->hwnd_parent, WM_COMMAND, p->unit_pos, p->hwnd );
		}
	}


	return ret;
}

n_posix_bool
n_win_scrollbar_scroll_unit( n_win_scrollbar *p, n_type_real unit_delta, int option )
{
//n_win_scrollbar_debug_count( p );

//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " n_win_scrollbar_scroll_unit() " ); }

	if ( unit_delta != 0 )
	{

		p->prev_pos = p->unit_pos;


		p->unit_pos += unit_delta;


		n_type_real unit_min = 0;
		n_type_real unit_max = n_win_scrollbar_position_last_unit( p );

		p->unit_pos = n_posix_minmax_n_type_real( unit_min, unit_max, p->unit_pos );

//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " %g %g %g ", p->unit_pos, p->unit_page, unit_max ); }


		n_type_real pixel_min = 0;
		n_type_real pixel_max = n_win_scrollbar_position_last_pixel( p );

		n_type_real d = 0;
		if ( p->option & N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX ) { d = p->pixel_patch; }

		p->pixel_pos = n_win_scrollbar_position_unit2pixel( p );
		p->pixel_pos = n_posix_minmax_n_type_real( pixel_min, pixel_max - d, p->pixel_pos );

//if ( p->layout == 1 ) { n_win_scrollbar_hwndprintf_literal( p, " %g %g ", p->pixel_pos, pixel_max ); }
	}


	n_posix_bool ret = n_posix_false;
	if ( option == N_WIN_SCROLLBAR_SCROLL_NONE )
	{
		//
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_SEND )
	{
		n_win_message_send( p->hwnd_parent, WM_COMMAND, (int) p->unit_pos, p->hwnd );
		ret = n_posix_true;
	} else
	if ( option == N_WIN_SCROLLBAR_SCROLL_AUTO )
	{
		ret = ( 1 <= fabs( p->prev_pos - p->unit_pos ) );
		if ( ret )
		{
			n_win_message_send( p->hwnd_parent, WM_COMMAND, (int) p->unit_pos, p->hwnd );
		}
	}


	return ret;
}

void
n_win_scrollbar_reset( n_win_scrollbar *p )
{

	p->unit_pos = p->pixel_pos = 0;

	n_win_scrollbar_scroll_pixel( p, 0, N_WIN_SCROLLBAR_SCROLL_SEND );


	return;
}

void
n_win_scrollbar_thumb_rect_set( n_win_scrollbar *p, n_type_real *ret_x, n_type_real *ret_y )
{

	// [!] : position

	n_type_real dx,dy; n_win_scrollbar_position_thumb( p, &dx, &dy );


	// [!] : offset

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		dx += p->pixel_arrow_sx;
	} else {
		dy += p->pixel_arrow_sy;
	}


	if ( ret_x != NULL ) { (*ret_x) = dx; }
	if ( ret_y != NULL ) { (*ret_y) = dy; }


	// [!] : size

	n_type_gfx bmpsx = N_BMP_SX( &p->bmp_th );
	n_type_gfx bmpsy = N_BMP_SY( &p->bmp_th );


	// [!] : for collision/hittest

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		dx += p->rect_main.x;
		dy += p->rect_main.y;
	}


	n_win_scrollbar_rect_set( &p->rect_thumb, dx,dy,bmpsx,bmpsy );


	return;
}


#define n_win_scrollbar_draw( p ) n_win_scrollbar_draw_always( p, n_posix_false )

static n_posix_bool n_win_scrollbar_draw_always_printclient = n_posix_false;

void
n_win_scrollbar_draw_always( n_win_scrollbar *p, n_posix_bool always )
{

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		if ( n_posix_false == p->show_onoff       ) { return; }
	} else {
		if ( n_posix_false == IsWindow( p->hwnd ) ) { return; }
	}


	if ( always == n_posix_false )
	{
		if ( p->drag_onoff == n_posix_false )
		{
			if (
				( p->fade_thumb   .stop )
				&&
				( p->fade_arrow_ul.stop )
				&&
				( p->fade_arrow_dr.stop )
			)
			{
				return;
			}
		} else {
			if (
				( p->prev_pos == p->unit_pos )
				&&
				( p->fade_thumb   .stop )
				&&
				( p->fade_arrow_ul.stop )
				&&
				( p->fade_arrow_dr.stop )
			)
			{

				n_win_scrollbar_thumb_rect_set( p, NULL, NULL );

				return;
			}
		}
	}
//n_win_scrollbar_debug_count();


	if ( n_bmp_error( &p->bmp_mainbuffer ) ) { return; }


	// UI Maker

	n_win_scrollbar_metrics( p );

	n_win_scrollbar_arrowbutton_onoff( p, 0, n_win_scrollbar_position_last_pixel( p ), p->pixel_pos );

	p->fade_color_thumb    = n_bmp_fade_engine( &p->fade_thumb   , p->fade_onoff );
	p->fade_color_arrow_ul = n_bmp_fade_engine( &p->fade_arrow_ul, p->fade_onoff );
	p->fade_color_arrow_dr = n_bmp_fade_engine( &p->fade_arrow_dr, p->fade_onoff );

	// [Needed] : see OrangeCat
	if ( p->fade_thumb   .stop == n_posix_false ) { n_bmp_free( &p->bmp_th ); }
	if ( p->fade_arrow_ul.stop == n_posix_false ) { n_bmp_free( &p->bmp_ul ); }
	if ( p->fade_arrow_dr.stop == n_posix_false ) { n_bmp_free( &p->bmp_dr ); }

//if ( NULL == N_BMP_PTR( &p->bmp_th ) ) { n_win_scrollbar_debug_count( p ); }

	n_posix_bool redraw_ul = ( ( NULL == N_BMP_PTR( &p->bmp_ul ) )||( p->enabled_ul == n_posix_false ) );
	n_posix_bool redraw_dr = ( ( NULL == N_BMP_PTR( &p->bmp_dr ) )||( p->enabled_dr == n_posix_false ) );

	// [!] : for a smaller window

	n_type_real size;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		size = p->rect_main.sx;
	} else {
		size = p->rect_main.sy;
	}

//n_win_scrollbar_hwndprintf_literal( p, " %f ", size );

	n_type_gfx ox_tl = 0;
	n_type_gfx oy_tl = 0;
	n_type_gfx ox_dr = 0;
	n_type_gfx oy_dr = 0;

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		n_type_real d = N_WIN_SCROLLBAR_RECT_NONE;

		n_win_scrollbar_rect_set( &p->rect_arrow_ul, d,d,d,d );
		n_win_scrollbar_rect_set( &p->rect_arrow_dr, d,d,d,d );

	} else {

		if ( size > ( p->pixel_arrow_sx + p->pixel_minim + p->pixel_arrow_sy ) )
		{
			//
		} else {
			if ( ( p->win8_onoff )&&( p->style == N_WIN_SCROLLBAR_STYLE_VISUALSTYLE ) )
			{
				if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
				{
					p->pixel_arrow_sx = size / 2;
				} else {
					p->pixel_arrow_sy = size / 2;
				}
			} else {
				if ( size < ( p->pixel_arrow_sx + p->pixel_arrow_sy ) )
				{
					if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
					{
						p->pixel_arrow_sx = 0;
					} else {
						p->pixel_arrow_sy = 0;
					}
				}
			}
			if ( p->enabled ) { p->enabled_ul = p->enabled_dr = n_posix_true; }
		}


		// [!] : Top / Left

		// [!] : for collision/hittest

		n_type_gfx hit_x_tl = ox_tl;
		n_type_gfx hit_y_tl = oy_tl;

		if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
		{
			hit_x_tl = ox_tl + (n_type_gfx) p->rect_main.x;
			hit_y_tl = oy_tl + (n_type_gfx) p->rect_main.y;
		}

		n_win_scrollbar_rect_set( &p->rect_arrow_ul, hit_x_tl,hit_y_tl,p->pixel_arrow_sx,p->pixel_arrow_sy );


		// [!] : Bottom / Right

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			ox_dr = (n_type_gfx) ( p->rect_main.sx - p->pixel_arrow_sx );
			oy_dr = 0;
		} else {
			ox_dr = 0;
			oy_dr = (n_type_gfx) ( p->rect_main.sy - p->pixel_arrow_sy );
		}

		// [!] : for collision/hittest

		n_type_gfx hit_x_dr = ox_dr;
		n_type_gfx hit_y_dr = oy_dr;

		if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
		{
			hit_x_dr = ox_dr + (n_type_gfx) p->rect_main.x;
			hit_y_dr = oy_dr + (n_type_gfx) p->rect_main.y;
		}

		n_win_scrollbar_rect_set( &p->rect_arrow_dr, hit_x_dr,hit_y_dr,p->pixel_arrow_sx,p->pixel_arrow_sy );

	}

	n_win_scrollbar_ui( p );


	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_FASTMODE )
	{

		//

	} else {

		p->redraw_count++;
		if ( p->redraw_count <= 1 ) { return; } else { p->redraw_count = 1; }

//if ( n_win_scrollbar_debug_instance == p ) { n_win_scrollbar_debug_count( p ); }

	}


	n_posix_bool shaft_color_is_visualstyle = n_posix_false;
	n_type_gfx   shaft_color_sy             = 0;

	if ( p->option & N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR )
	{

		shaft_color_is_visualstyle = ( n_posix_false == n_win_style_is_classic() );
		if ( shaft_color_is_visualstyle ) { shaft_color_sy = 1; }

		n_type_gfx sx = (n_type_gfx) ( p->rect_shaft.sx - ( p->pixel_arrow_sx * 2 ) );
		n_type_gfx sy = (n_type_gfx) ( p->rect_shaft.sy - shaft_color_sy );

		if ( NULL == N_BMP_PTR( &p->bmp_gr ) )
		{
			n_bmp_new( &p->bmp_gr, sx,sy );

			if ( p->color_sh_fg == p->color_sh_bg )
			{

				n_bmp_flush( &p->bmp_gr, p->color_sh_fg );

			} else {

				int mode = N_BMP_GRADIENT_CIRCLE;

				int type;
				if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
				{
					type = N_BMP_GRADIENT_HORIZONTAL;
				} else {
					type = N_BMP_GRADIENT_VERTICAL;
				}

				int lightness_fg = n_bmp_l( n_bmp_argb2ahsl( p->color_sh_fg ) );
				int lightness_bg = n_bmp_l( n_bmp_argb2ahsl( p->color_sh_bg ) );

				if ( lightness_fg < lightness_bg )
				{
					n_bmp_flush_gradient( &p->bmp_gr, p->color_sh_bg, p->color_sh_fg, mode | type );
				} else {
					n_bmp_flush_gradient( &p->bmp_gr, p->color_sh_fg, p->color_sh_bg, mode | type );
					n_bmp_flush_mirror( &p->bmp_gr, N_BMP_MIRROR_LEFTSIDE_RIGHT );
				}

			}

			if (
				( shaft_color_is_visualstyle )
				&&
				( n_sysinfo_version_xp() )
			)
			{
				n_bmp_cornermask( &p->bmp_gr, 4, 0, n_bmp_white_invisible );
			}
		}

	}


	n_type_gfx rx  = p->redraw_x;
	n_type_gfx ry  = p->redraw_y;
	n_type_gfx rsx = p->redraw_sx;
	n_type_gfx rsy = p->redraw_sy;


	// Background

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DWM_ON )
	{
		n_bmp_box( &p->bmp_mainbuffer, rx,ry,rsx,rsy, n_bmp_argb( 16, 1,1,1 ) );
	} else {
		if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
		{
			n_bmp_box( &p->bmp_mainbuffer, rx,ry,rsx,rsy, p->color__back );
		}
	}


	// Shaft

	if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
	{
		n_bmp_transcopy( &p->bmp_sh, &p->bmp_mainbuffer, rx,ry,rsx,rsy, rx,ry );
	} else {
		n_bmp_fastcopy ( &p->bmp_sh, &p->bmp_mainbuffer, rx,ry,rsx,rsy, rx,ry );
	}

	if ( p->option & N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR )
	{
		n_type_gfx sx = (n_type_gfx) ( p->rect_shaft.sx - ( p->pixel_arrow_sx * 2 ) );
		n_type_gfx sy = (n_type_gfx) ( p->rect_shaft.sy - shaft_color_sy );
		n_type_gfx  y = shaft_color_sy;

		n_bmp_blendcopy( &p->bmp_gr, &p->bmp_mainbuffer, 0,0,sx,sy, (n_type_gfx) p->pixel_arrow_sx,y, 0.0 );
	}


	// Arrows

	if ( p->option & N_WIN_SCROLLBAR_OPTION_NO_ARROWS )
	{

		n_type_real d = N_WIN_SCROLLBAR_RECT_NONE;

		n_win_scrollbar_rect_set( &p->rect_arrow_ul, d,d,d,d );
		n_win_scrollbar_rect_set( &p->rect_arrow_dr, d,d,d,d );

	} else {

		// [!] : Top / Left

//n_bmp_box( &p->bmp_mainbuffer, ox_tl,oy_tl, p->pixel_arrow_sx,p->pixel_arrow_sy, n_bmp_rgb( 255,0,255 ) );

		if ( redraw_ul )
		{
			if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
			{
				n_bmp_transcopy( &p->bmp_ul, &p->bmp_mainbuffer, 0,0,(n_type_gfx) p->pixel_arrow_sx,(n_type_gfx) p->pixel_arrow_sy, ox_tl,oy_tl );
			} else {
				n_bmp_fastcopy ( &p->bmp_ul, &p->bmp_mainbuffer, 0,0,(n_type_gfx) p->pixel_arrow_sx,(n_type_gfx) p->pixel_arrow_sy, ox_tl,oy_tl );
			}
		}

		// [!] : Bottom / Right

//n_bmp_box( &p->bmp_mainbuffer, ox_dr,oy_dr, p->pixel_arrow_sx,p->pixel_arrow_sy, n_bmp_rgb( 255,255,0 ) );

		if ( redraw_dr )
		{
			if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
			{
				n_bmp_transcopy( &p->bmp_dr, &p->bmp_mainbuffer, 0,0,(n_type_gfx) p->pixel_arrow_sx,(n_type_gfx) p->pixel_arrow_sy, ox_dr,oy_dr );
			} else {
				n_bmp_fastcopy ( &p->bmp_dr, &p->bmp_mainbuffer, 0,0,(n_type_gfx) p->pixel_arrow_sx,(n_type_gfx) p->pixel_arrow_sy, ox_dr,oy_dr );
			}
		}

	}


	// Thumb

	if (
		( p->option & N_WIN_SCROLLBAR_OPTION_DRAW_100PC )
		||
		( size >= ( p->pixel_arrow_sx + p->pixel_thumb + p->pixel_arrow_sy ) )
	)
	{

		n_type_real dx,dy;
		n_win_scrollbar_thumb_rect_set( p, &dx, &dy );

		if ( ( p->enabled )||( p->option & N_WIN_SCROLLBAR_OPTION_DRAW_100PC ) )
		{
			n_type_gfx int_x = (n_type_gfx) trunc( dx );
			n_type_gfx int_y = (n_type_gfx) trunc( dy );

			if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
			{
				int_x -= int_x % p->scale;
			} else {
				int_y -= int_y % p->scale;
			}

			if ( p->option & N_WIN_SCROLLBAR_OPTION_RECALC_UNIT_MAX )
			{
				if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
				{
					int_x = n_posix_min_n_type_gfx( int_x, (n_type_gfx) ( p->pixel_max - p->pixel_patch ) );
				} else {
					int_y = n_posix_min_n_type_gfx( int_y, (n_type_gfx) ( p->pixel_max - p->pixel_patch ) );
				}
			}

			n_type_gfx bmpsx = N_BMP_SX( &p->bmp_th );
			n_type_gfx bmpsy = N_BMP_SY( &p->bmp_th );

			if ( p->style == N_WIN_SCROLLBAR_STYLE_STRIPE_ROUND )
			{
				n_bmp_transcopy( &p->bmp_th, &p->bmp_mainbuffer, 0,0,bmpsx,bmpsy, int_x,int_y );
			} else {
				n_bmp_fastcopy ( &p->bmp_th, &p->bmp_mainbuffer, 0,0,bmpsx,bmpsy, int_x,int_y );
			}

			p->redraw_x  = int_x;
			p->redraw_y  = int_y;
			p->redraw_sx = bmpsx;
			p->redraw_sy = bmpsy;

			if ( p->option & N_WIN_SCROLLBAR_OPTION_SHAFT_COLOR )
			{
				n_type_gfx sx = (n_type_gfx) ( p->rect_shaft.sx - ( p->pixel_arrow_sx * 2 ) );
				n_type_gfx sy = (n_type_gfx) ( p->rect_shaft.sy - shaft_color_sy );
				n_type_gfx  y = shaft_color_sy;

				n_bmp_blendcopy( &p->bmp_gr, &p->bmp_mainbuffer, 0,0,sx,sy, (n_type_gfx) p->pixel_arrow_sx,y, 0.75 );
			}

		}

	}

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	if (
		( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
		||
		( n_win_scrollbar_draw_always_printclient )
	)
	{
		x = (n_type_gfx) p->rect_main.x;
		y = (n_type_gfx) p->rect_main.y;
	}


	if ( p->style == N_WIN_SCROLLBAR_STYLE_FLUENT_UI )
	{
		if ( p->bmp_parent == NULL )
		{
			u32 check; n_bmp_ptr_get_fast( &p->bmp_mainbuffer, 0,0, &check );
			if ( check != p->color_edge_ul )
			{
				n_type_gfx round = n_win_fluent_ui_round_param( p->hwnd );

				n_bmp_cornermask_rich
				(
					&p->bmp_mainbuffer,
					round,
					0,
					p->color_edge_ul,
					p->color_edge_ur,
					p->color_edge_dl,
					p->color_edge_dr
				);
			}
		} else {
//n_bmp_box( &p->bmp_mainbuffer, 0,0,p->sx,p->sy, n_bmp_rgb( 255,0,0 ) );
//n_bmp_save_literal( p->bmp_parent, "ret.bmp" );

			n_type_gfx x = (n_type_gfx) p->rect_main.x;
			n_type_gfx y = (n_type_gfx) p->rect_main.y;

			n_bmp_transcopy( p->bmp_parent, &p->bmp_mainbuffer, x,y,p->sx,p->sy, 0,0 );
//n_bmp_save_literal( &p->bmp_mainbuffer, "ret.bmp" );
		}
	}

//n_bmp_save_literal( &p->bmp_mainbuffer, "ret.bmp" );


	// [!] : crash : you cannot use DIBSection for p->bmp_backbuffer

	if ( p->bmp_backbuffer != NULL )
	{
		n_bmp_fastcopy( &p->bmp_mainbuffer, p->bmp_backbuffer, 0,0,p->sx,p->sy, x,y );
	} else {
		n_gdi_bitmap_draw_main( p->hwnd, p->hdc, &p->bmp_mainbuffer, 0,0,p->sx,p->sy, x,y );
	}
/*
	if ( n_gdiplus_is_on() )
	{
//n_posix_debug_literal( "!" );
		if ( NULL != N_BMP_PTR( &game.bmp ) )
		{
			n_gdiplus_draw( p->hdc, N_BMP_PTR( p->bmp_backbuffer ), p->sx,p->sy );
		}
	}
*/


/*
if ( n_win_scrollbar_debug_instance == p )
{
	static int i = 0;

	if ( i == 0 ) { n_bmp_save_literal( &p->bmp_mainbuffer, "0.bmp" ); }
	if ( i == 1 ) { n_bmp_save_literal( &p->bmp_mainbuffer, "1.bmp" ); }

	i++;
}
*/


	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		if ( p->direct_render_callback != NULL )
		{
			p->direct_render_callback( p->direct_render_callback_data );
		}
	}


#ifdef _H_NONNON_WIN32_GAME

	n_game_refresh_on();

#endif // #ifdef _H_NONNON_WIN32_GAME


	return;
}

void
n_win_scrollbar_move( n_win_scrollbar *p, n_type_gfx x, n_type_gfx y, n_type_gfx sx, n_type_gfx sy, n_posix_bool redraw )
{

	n_type_real px,py,psx,psy; n_win_scrollbar_rect_get( &p->rect_main, &px,&py,&psx,&psy );
	n_posix_bool is_changed = ( ( x != px )||( y != py )||( sx != psx )||( sy != psy ) );


	n_posix_bool is_last = ( ( p->enabled )&&( p->enabled_dr == n_posix_false ) );


	n_win_scrollbar_rect_set( &p->rect_main, x,y,sx,sy );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		//
	} else {
		n_win_move_simple( p->hwnd, x,y,sx,sy, redraw );
	}


	p->init_onoff = n_posix_true;

	n_win_scrollbar_metrics( p );


	n_bmp_new_fast( &p->bmp_mainbuffer, p->sx,p->sy );

	p->redraw_x  = 0;
	p->redraw_y  = 0;
	p->redraw_sx = p->sx;
	p->redraw_sy = p->sy;


	n_type_real unit_prev = p->unit_pos;

	if ( is_changed )
	{

//if ( n_win_scrollbar_debug_instance == p ) { n_posix_debug_literal( "" ); }

		// [Needed] : always draw when resized
		redraw = n_posix_true;

		if ( is_last )
		{
//n_win_scrollbar_hwndprintf_literal( p, " is_last " );

			p->unit_pos = p->unit_max;

			extern n_posix_bool n_win_scrollbar_scroll_unit( n_win_scrollbar*, n_type_real, int );
			n_win_scrollbar_scroll_unit( p, 0, N_WIN_SCROLLBAR_SCROLL_AUTO );

		} else
		if ( unit_prev > 0 )
		{
//n_win_scrollbar_hwndprintf_literal( p, " middle %d",p->enabled_dr );

			if ( p->unit_pos != unit_prev )
			{
				n_type_real unit_pos = unit_prev;
				p->unit_pos = 0;

				extern n_posix_bool n_win_scrollbar_scroll_unit( n_win_scrollbar*, n_type_real, int );
				n_win_scrollbar_scroll_unit( p, unit_pos, N_WIN_SCROLLBAR_SCROLL_AUTO );
			}

//n_win_scrollbar_hwndprintf_literal( p, " middle : %g %g ", p->unit_pos + p->unit_page, n_win_scrollbar_position_last_unit( p ) );

			if ( ( p->unit_pos + p->unit_page ) >= p->unit_max )
			{
//n_win_scrollbar_hwndprintf_literal( p, " middle : last " );

				n_type_real pixel_pos = p->pixel_max;
				p->pixel_pos = 0;

				extern n_posix_bool n_win_scrollbar_scroll_pixel( n_win_scrollbar*, n_type_real, int );
				n_win_scrollbar_scroll_pixel( p, pixel_pos, N_WIN_SCROLLBAR_SCROLL_AUTO );
			}

		}

	}


	// [!] : use n_posix_false for logic like carrage-return in TxtBox

	if ( redraw )
	{
		n_win_scrollbar_refresh( p );
	}


	return;
}

n_type_real
n_win_scrollbar_pager( n_win_scrollbar *p, n_type_gfx cursor_x, n_type_gfx cursor_y )
{

	// [!] : Nonnon Original Scrollpager

	n_type_real pos = 0;

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		pos = cursor_x - p->pixel_arrow_sx - ( p->pixel_thumb / 2 );
	} else {
		pos = cursor_y - p->pixel_arrow_sy - ( p->pixel_thumb / 2 );
	}


	return pos;
}

void
n_win_scrollbar_event_shaft( n_win_scrollbar *p )
{

	p->arrow_is_event_running = n_posix_true;


	n_type_gfx cursor_x, cursor_y; n_win_scrollbar_position_cursor( p, &cursor_x, &cursor_y );

	if ( p->option & N_WIN_SCROLLBAR_OPTION_PAGER )
	{

		n_type_real pos = n_win_scrollbar_pager( p, cursor_x, cursor_y );
		p->pixel_pos = 0;

		n_win_scrollbar_scroll_pixel( p, pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

		n_win_scrollbar_draw_always( p, n_posix_true );

	} else {

		n_type_real delta = 0;

		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			if ( cursor_x < p->rect_thumb.x )
			{
				delta = -p->unit_page;
			} else
			if ( cursor_x > p->rect_thumb.x )
			{
				delta =  p->unit_page;
			}
		} else {
			if ( cursor_y < p->rect_thumb.y )
			{
				delta = -p->unit_page;
			} else
			if ( cursor_y > p->rect_thumb.y )
			{
				delta =  p->unit_page;
			}
		}
//n_posix_debug_literal( " %f ", delta );

		if ( n_win_scrollbar_scroll_unit( p, delta, N_WIN_SCROLLBAR_SCROLL_AUTO ) )
		{
			n_win_scrollbar_draw_always( p, n_posix_true );
		}
	
	}


	p->arrow_is_event_running = n_posix_false;


	return;
}

void
n_win_scrollbar_event_arrow( n_win_scrollbar *p )
{

	p->arrow_is_event_running = n_posix_true;


	n_type_real delta = 0;

	if ( p->pressed_arrow_ul )
	{
		delta = -p->unit_step;
	} else
	if ( p->pressed_arrow_dr )
	{
		delta =  p->unit_step;
	}

	if ( delta != 0 )
	{

		if ( n_win_scrollbar_scroll_unit( p, delta, N_WIN_SCROLLBAR_SCROLL_AUTO ) )
		{
			n_win_scrollbar_draw_always( p, n_posix_true );
		}

	}


	p->arrow_is_event_running = n_posix_false;


	return;
}

void
n_win_scrollbar_on_input( n_win_scrollbar *p )
{
//if ( n_win_is_input( VK_CONTROL ) ) { n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", p->hwnd, GetParent( p->hwnd ), n_win_hwnd_window( p->hwnd ) ); }
//if ( n_win_is_input( VK_CONTROL ) ) { n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", GetActiveWindow(), n_win_hwnd_toplevel( p->hwnd ), n_win_cursor2hwnd() ); }
//if ( n_win_is_input( VK_CONTROL ) ) { n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", GetActiveWindow(), n_win_hwnd_toplevel( p->hwnd ), GetForegroundWindow() ); }
//if ( n_win_is_input( VK_CONTROL ) ) { n_win_scrollbar_hwndprintf_literal( p, " %x %x ", p->hwnd, n_win_cursor2hwnd_relative( p->hwnd_parent ) ); }
//if ( p->layout == 1 )  { n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", GetActiveWindow(), GetForegroundWindow(), n_win_hwnd_window( p->hwnd_parent ) ); }

	if ( GetActiveWindow() != n_win_hwnd_window( p->hwnd_parent ) )
	{

		p->hovered_main     = n_posix_false;
		p->hovered_thumb    = n_posix_false;
		p->hovered_arrow_ul = n_posix_false;
		p->hovered_arrow_dr = n_posix_false;
		p->hovered_shaft    = n_posix_false;

		return;
	}


	if ( p->show_onoff == n_posix_false ) { return; }


	p->hovered_main     = n_win_scrollbar_rect_is_hovered( &p->rect_main    , p->hwnd );
	p->hovered_thumb    = n_win_scrollbar_rect_is_hovered( &p->rect_thumb   , p->hwnd );
	p->hovered_arrow_ul = n_win_scrollbar_rect_is_hovered( &p->rect_arrow_ul, p->hwnd );
	p->hovered_arrow_dr = n_win_scrollbar_rect_is_hovered( &p->rect_arrow_dr, p->hwnd );
	p->hovered_shaft    = n_win_scrollbar_rect_is_hovered( &p->rect_shaft   , p->hwnd );

	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_thumb    == n_posix_false );
	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_arrow_ul == n_posix_false );
	p->hovered_shaft    = p->hovered_shaft && ( p->hovered_arrow_dr == n_posix_false );


//n_win_scrollbar_hwndprintf_literal( p, " %d %d %d ", p->hovered_main, p->hovered_thumb, p->hovered_shaft );
	return;
}

void
n_win_scrollbar_offset( n_win_scrollbar *p )
{

	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		p->pixel_offset = p->prv_cursor_x - p->rect_thumb.x;
	} else {
		p->pixel_offset = p->prv_cursor_y - p->rect_thumb.y;
	}

	if ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
	{
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			p->pixel_offset += p->rect_main.x;
		} else {
			p->pixel_offset += p->rect_main.y;
		}
	}


	return;
}

void
n_win_scrollbar_on_drag( n_win_scrollbar *p )
{
//return;

	n_win_scrollbar_position_cursor( p, &p->cur_cursor_x, &p->cur_cursor_y );


	n_type_real pixel_delta;
//if(pixel_delta){}
	if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		pixel_delta = p->cur_cursor_x - p->prv_cursor_x;
	} else {
		pixel_delta = p->cur_cursor_y - p->prv_cursor_y;
	}
//n_win_scrollbar_hwndprintf_literal( p, " %f ", pixel_delta );

//n_win_scrollbar_hwndprintf_literal( p, " %g %g ", p->pixel_pos, p->pixel_max - p->pixel_page );


//n_win_scrollbar_hwndprintf_literal( p, " %d %d ", p->cur_cursor_y, (int) p->pixel_arrow_sy );

	n_posix_bool draw_always_onoff = n_posix_false;

	if ( ( p->drag_clamp )&&( pixel_delta != 0.0 ) )
	{

		n_type_gfx arrow;
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			arrow = (n_type_gfx) p->pixel_arrow_sx;
		} else {
			arrow = (n_type_gfx) p->pixel_arrow_sy;
		}

		n_type_gfx cursor;
		if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
		{
			cursor = p->cur_cursor_x - arrow;
		} else {
			cursor = p->cur_cursor_y - arrow;
		}

		n_type_gfx minim = 0;
		n_type_gfx maxim = (n_type_gfx) p->pixel_shaft;

		minim += (n_type_gfx) (                  p->pixel_offset_prv );
		maxim -= (n_type_gfx) ( p->pixel_thumb - p->pixel_offset_prv );

		if ( cursor <= minim )
		{
//n_win_scrollbar_hwndprintf_literal( p, " minim " );
//n_win_scrollbar_debug_count();

			// [Needed] : set -1 for "pixel_delta"
			//
			//	when released at outside of thumb

			p->pixel_offset = p->pixel_offset_prv;
			p->pixel_pos    = 0;
			   pixel_delta  = -1;

			draw_always_onoff = n_posix_true;

		} else
		if ( cursor >= maxim )
		{
//n_win_scrollbar_hwndprintf_literal( p, " maxim " );
//n_win_scrollbar_hwndprintf_literal( p, " %d %d ", p->cur_cursor_y, p->pixel_arrow_sy );

//if ( p->layout == N_WIN_SCROLLBAR_LAYOUT_VERTICAL )
//{
//	n_win_scrollbar_hwndprintf_literal( p, " %d %d ", (int) p->pixel_shaft, (int) p->sy );
//}

			p->pixel_offset = p->pixel_offset_prv;
			p->pixel_pos    = 0;
			   pixel_delta  = p->pixel_shaft;

			draw_always_onoff = n_posix_true;

		} else {
//n_win_scrollbar_hwndprintf_literal( p, " else " );
		}

//n_win_scrollbar_hwndprintf_literal( p, " %d %d : %d : %d ", minim, maxim, (n_type_gfx) p->pixel_offset, cursor );
	}


//n_win_scrollbar_hwndprintf_literal( p, " %f %f ", p->pixel_pos, p->pixel_step );

	if ( draw_always_onoff )
	{
		n_win_scrollbar_scroll_pixel( p, pixel_delta, N_WIN_SCROLLBAR_SCROLL_AUTO );

//n_win_scrollbar_draw_always( p, n_posix_true );
		n_win_scrollbar_refresh_redraw_area( p );
		n_win_scrollbar_refresh( p );
	} else {
		n_posix_bool ret = n_win_scrollbar_scroll_pixel( p, pixel_delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
		if ( ret ) { n_win_scrollbar_draw( p ); }
	}


	p->prv_cursor_x = p->cur_cursor_x;
	p->prv_cursor_y = p->cur_cursor_y;


	return;
}

n_posix_bool
n_win_scrollbar_fade_go( n_win_scrollbar *p, n_bmp_fade *fade, n_bmp *bmp, u32 color )
{

	n_posix_bool redraw = n_posix_false;

	n_bmp_fade_go( fade, color );
	if ( n_posix_false == fade->stop )
	{
//n_win_scrollbar_debug_count( p );

		redraw = n_posix_true;

		n_bmp_free( bmp );
	}

	return redraw;
}

static HWND n_win_scrollbar_hwnd_global = NULL;
static n_posix_bool n_win_scrollbar_printclient = n_posix_false;

void
n_win_scrollbar_subclass( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_scrollbar *p )
{

	if ( p->stop_onoff ) { return; }


	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }
//n_win_scrollbar_debug_count( p );

		if ( di->hwndItem == p->hwnd )
		{
			if ( p->option & N_WIN_SCROLLBAR_OPTION_USE_DI_HDC )
			{
				p->hdc = di->hDC;
			} else {
				p->hdc = NULL;
			}
			n_win_scrollbar_draw_always( p, n_posix_true );
		}

	}
	break;


	case WM_PRINTCLIENT :

		if ( n_win_scrollbar_printclient == n_posix_false ) { break; }

		p->hdc = (HDC) wparam;
		n_win_scrollbar_draw_always( p, n_posix_true );

	break;


	case WM_TIMER :
	{

		if ( wparam == 0 ) { break; }

		if ( wparam != p->timer_id ) { break; }
//n_win_scrollbar_debug_count();


		// [Needed] : important for fading

		if (
			( p->fade_thumb   .stop == n_posix_false )
			||
			( p->fade_arrow_ul.stop == n_posix_false )
			||
			( p->fade_arrow_dr.stop == n_posix_false )
		)
		{
//n_win_scrollbar_debug_count();
//n_win_scrollbar_hwndprintf_literal( p, " %d %d %d ", p->fade_thumb.stop, p->fade_arrow_ul.stop, p->fade_arrow_dr.stop );
			n_win_scrollbar_draw( p );
		}


		if ( p->enabled == n_posix_false ) { break; }


		n_win_scrollbar_on_input( p );

		if ( p->drag_onoff )
		{
//n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", hwnd, p->hwnd, n_win_scrollbar_hwnd_global );

			if ( n_win_scrollbar_hwnd_global ==    NULL ) { break; }
			if ( n_win_scrollbar_hwnd_global != p->hwnd ) { break; }

//n_win_scrollbar_hwndprintf_literal( p, " WM_TIMER " );

			n_win_scrollbar_on_drag( p );

		} else
		if ( p->hovered_thumb )
		{

			if ( n_win_is_input( VK_LBUTTON ) )
			{

				if ( n_win_scrollbar_hwnd_global ==    NULL ) { break; }
				if ( n_win_scrollbar_hwnd_global != p->hwnd ) { break; }

			}


			n_posix_bool redraw = n_posix_false;

			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_t );

			if ( redraw ) { n_win_scrollbar_draw( p ); }

		} else
		if ( p->hovered_arrow_ul )
		{

			if ( p->enabled_ul == n_posix_false )
			{
				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_s );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

				break;
			}


			if ( n_win_is_input( VK_LBUTTON ) )
			{

				if ( n_win_scrollbar_hwnd_global ==    NULL ) { break; }
				if ( n_win_scrollbar_hwnd_global != p->hwnd ) { break; }


				n_posix_bool is_pressed = n_posix_false;

				if ( p->timer_pressing < n_posix_tickcount() )
				{
					is_pressed = n_posix_true;

					n_win_scrollbar_event_arrow( p );
				}


				// [!] : always on

				n_posix_bool redraw = n_posix_true;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_press );

				if ( redraw ) { n_win_scrollbar_draw( p ); }


				if ( is_pressed )
				{
					p->rapid_fire     = 1;//n_posix_max( 1, p->rapid_fire / 2 );
					p->timer_pressing = n_posix_tickcount() + p->rapid_fire;
				}

			} else {

				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_s );
				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_hvr_t );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_arrow_dr )
		{

			if ( p->enabled_dr == n_posix_false )
			{
				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_s );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

				break;
			}


			if ( n_win_is_input( VK_LBUTTON ) )
			{

				if ( n_win_scrollbar_hwnd_global ==    NULL ) { break; }
				if ( n_win_scrollbar_hwnd_global != p->hwnd ) { break; }


				n_posix_bool is_pressed = n_posix_false;

				if ( p->timer_pressing < n_posix_tickcount() )
				{
					is_pressed = n_posix_true;

					n_win_scrollbar_event_arrow( p );
				}


				// [!] : always on

				n_posix_bool redraw = n_posix_true;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_press );

				if ( redraw ) { n_win_scrollbar_draw( p ); }


				if ( is_pressed )
				{
					p->rapid_fire     = 1;//n_posix_max( 1, p->rapid_fire / 2 );
					p->timer_pressing = n_posix_tickcount() + p->rapid_fire;
				}

			} else {

				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_s );
				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_hvr_t );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_shaft )
		{
//n_win_scrollbar_hwndprintf_literal( p, " %x %x %x ", hwnd, p->hwnd, n_win_scrollbar_hwnd_global );
//break;

			if ( ( p->timer_pressing < n_posix_tickcount() )&&( n_win_is_input( VK_LBUTTON ) ) )
			{

				if ( n_win_scrollbar_hwnd_global ==    NULL ) { break; }
				if ( n_win_scrollbar_hwnd_global != p->hwnd ) { break; }


				n_win_scrollbar_event_shaft( p );


				p->rapid_fire     = 1;//n_posix_max( 1, p->rapid_fire / 2 );
				p->timer_pressing = n_posix_tickcount() + p->rapid_fire;

			} else {

				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_arbtn );
				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_arbtn );
				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_s );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if (
			(
				( n_posix_false == ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER ) )
				&&
				( p->hwnd != n_win_cursor2hwnd_relative( hwnd ) )
			)
			||
			(
				( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
				&&
				( p->hovered_main == n_posix_false )
			)
		)
		{

			n_posix_bool redraw = n_posix_false;

			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_thumb );

			if ( redraw ) { n_win_scrollbar_draw( p ); }

		}

	}
	break;


	} // switch


	return;
}

void
n_win_scrollbar_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, n_win_scrollbar *p )
{

	if ( p->stop_onoff ) { return; }


	switch( msg ) {


	case WM_LBUTTONDOWN   :
	case WM_LBUTTONDBLCLK :
	{
//n_win_hwndprintf_literal( hwnd, " WM_LBUTTONDOWN " );
//n_posix_debug_literal( " WM_LBUTTONDOWN " );


		if ( p->enabled == n_posix_false ) { break; }


		n_win_scrollbar_on_input( p );

		n_win_scrollbar_position_cursor( p, &p->prv_cursor_x, &p->prv_cursor_y );

		if ( p->hovered_thumb )
		{

			SetCapture( hwnd );


			p->pressed_thumb = n_posix_true;

			if ( p->drag_onoff == n_posix_false )
			{
//n_win_hwndprintf_literal( hwnd, " %d ", p->prv_cursor_y );
//n_win_hwndprintf_literal( hwnd, " hover_thumb " );

				p->drag_onoff = n_posix_true;


				n_win_scrollbar_offset( p );
				p->pixel_offset_prv = p->pixel_offset;


				p->rapid_fire     = N_WIN_SCROLLBAR_INTERVAL_PRESS;
				p->timer_pressing = n_posix_tickcount() + p->rapid_fire;


				n_posix_bool redraw = n_posix_false;

				p->fade_thumb.stop = n_posix_true;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_press );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_arrow_ul )
		{

			if ( p->enabled_ul == n_posix_false ) { break; }


			p->rapid_fire       = N_WIN_SCROLLBAR_INTERVAL_PRESS;
			p->timer_pressing   = n_posix_tickcount() + p->rapid_fire;
			p->pressed_arrow_ul = n_posix_true;


			n_posix_bool redraw = n_posix_false;

			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_press );

			if ( redraw ) { n_win_scrollbar_draw( p ); }

		} else
		if ( p->hovered_arrow_dr )
		{

			if ( p->enabled_dr == n_posix_false ) { break; }


			p->rapid_fire       = N_WIN_SCROLLBAR_INTERVAL_PRESS;
			p->timer_pressing   = n_posix_tickcount() + p->rapid_fire;
			p->pressed_arrow_dr = n_posix_true;


			n_posix_bool redraw = n_posix_false;

			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_press );

			if ( redraw ) { n_win_scrollbar_draw( p ); }

		} else
		if ( p->hovered_shaft )
		{
//n_win_scrollbar_hwndprintf_literal( p, " p->hovered_shaft " );

			p->rapid_fire     = N_WIN_SCROLLBAR_INTERVAL_PRESS;
			p->timer_pressing = n_posix_tickcount() + p->rapid_fire;
			p->pressed_shaft  = n_posix_true;

			n_win_scrollbar_event_shaft( p );

		}


		if (
			( p->pressed_thumb    )
			||
			( p->pressed_arrow_ul )
			||
			( p->pressed_arrow_dr )
			||
			( p->pressed_shaft    )
		)
		{
			n_win_scrollbar_hwnd_global = p->hwnd;
		}

	}
	break;


	case WM_LBUTTONUP :
	{

		if ( p->pressed_thumb ) { ReleaseCapture(); }


		if ( p->enabled == n_posix_false ) { break; }


		if ( ( n_win_scrollbar_hwnd_global != NULL )&&( n_win_scrollbar_hwnd_global != p->hwnd ) )
		{

			p->drag_onoff       = n_posix_false;
			p->pressed_thumb    = n_posix_false;
			p->pressed_arrow_ul = n_posix_false;
			p->pressed_arrow_dr = n_posix_false;
			p->pressed_shaft    = n_posix_false;

			n_win_scrollbar_hwnd_global = NULL;

			break;

		}


		n_win_scrollbar_on_input( p );

		if ( p->hovered_thumb )
		{

			if ( p->drag_onoff )
			{
//n_win_scrollbar_hwndprintf_literal( p, " WM_LBUTTONUP " );

				n_win_scrollbar_on_drag( p );


				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_hvr_t );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			} else {

				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_thumb );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_arrow_ul )
		{

			if ( p->enabled_ul )
			{

				n_win_scrollbar_event_arrow( p );


				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_hvr_t );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_arrow_dr )
		{

			if ( p->enabled_dr )
			{

				n_win_scrollbar_event_arrow( p );


				n_posix_bool redraw = n_posix_false;

				redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_hvr_t );

				if ( redraw ) { n_win_scrollbar_draw( p ); }

			}

		} else
		if ( p->hovered_shaft )
		{

			//

		} else
		if (
			(
				( n_posix_false == ( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER ) )
				&&
				( p->hwnd != n_win_cursor2hwnd_relative( hwnd ) )
			)
			||
			(
				( p->option & N_WIN_SCROLLBAR_OPTION_DIRECT_RENDER )
				&&
				( p->hovered_main == n_posix_false )
			)
		)
		{

			n_posix_bool redraw = n_posix_false;

			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_ul, &p->bmp_ul, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_arrow_dr, &p->bmp_dr, p->color_arbtn );
			redraw |= n_win_scrollbar_fade_go( p, &p->fade_thumb   , &p->bmp_th, p->color_thumb );

			if ( redraw ) { n_win_scrollbar_draw( p ); }

		}


		p->drag_onoff       = n_posix_false;
		p->pressed_thumb    = n_posix_false;
		p->pressed_arrow_ul = n_posix_false;
		p->pressed_arrow_dr = n_posix_false;
		p->pressed_shaft    = n_posix_false;

		n_win_scrollbar_hwnd_global = NULL;

	}
	break;


	case WM_RBUTTONDOWN :

		if ( p->show_onoff == n_posix_false ) { break; }
		if ( p->enabled    == n_posix_false ) { break; }

	break;

	case WM_RBUTTONUP :

		if ( p->show_onoff == n_posix_false ) { break; }
		if ( p->enabled    == n_posix_false ) { break; }

		n_win_scrollbar_on_input( p );

		if ( p->hovered_shaft )
		{
//n_win_scrollbar_hwndprintf_literal( p, " shaft " );

			n_win_scrollbar_position_cursor( p, &p->prv_cursor_x, &p->prv_cursor_y );

			n_win_simplemenu_show( &p->menu, hwnd );

		} else
		if ( p->hovered_thumb )
		{
//n_win_scrollbar_hwndprintf_literal( p, " thumb " );
		} else
		if ( p->hovered_arrow_ul )
		{
//n_win_scrollbar_hwndprintf_literal( p, " arrow up/left " );
		} else
		if ( p->hovered_arrow_dr )
		{
//n_win_scrollbar_hwndprintf_literal( p, " arrow down/right " );
		}

	break;


	case WM_COMMAND :

		if ( (HWND) lparam == p->menu.hwnd )
		{

			if ( wparam == N_WIN_SIMPLEMENU_WPARAM_REARRANGE )
			{

				//

			} else
			if ( wparam == 0 )
			{

				n_type_real pixel_pos = n_win_scrollbar_pager( p, p->prv_cursor_x, p->prv_cursor_y );
				p->pixel_pos = 0;

				n_win_scrollbar_scroll_pixel( p, pixel_pos, N_WIN_SCROLLBAR_SCROLL_AUTO );

				n_win_scrollbar_draw_always( p, n_posix_true );

			} else
			if ( wparam == 2 )
			{

				p->unit_pos = 0;

				n_win_scrollbar_refresh( p );

			} else
			if ( wparam == 3 )
			{

				p->unit_pos = p->unit_max;

				n_win_scrollbar_refresh( p );

			}// else

		}

	break;


	} // switch


	return;
}

void
n_win_scrollbar_window( n_win_scrollbar *h, n_win_scrollbar *v, n_win *w, COLORREF color_corner )
{

	n_posix_bool p_add_page = n_win_scrollbar_parameter_add_page;
	n_win_scrollbar_parameter_add_page = n_posix_false;


	n_type_gfx csx = w->csx;
	n_type_gfx csy = w->csy;


	n_win_scrollbar_parameter( h, 1, csx, w->rcsx, w->scrollx, n_posix_false );
	n_win_scrollbar_parameter( v, 1, csy, w->rcsy, w->scrolly, n_posix_false );


	n_posix_bool is_lefthanded = n_win_is_lefthanded();

	n_type_gfx sh = n_win_scrollbar_stdsize( h );
	n_type_gfx sv = n_win_scrollbar_stdsize( v );


	n_win_scrollbar_parameter_add_page = p_add_page;

	if ( w->rcsx > w->csx )
	{
		n_win_scrollbar_show( h, n_posix_true );

		n_type_gfx sx = w->csx;
		n_type_gfx sy = w->csy;

		n_type_gfx x = 0;
		if ( is_lefthanded ) { x = sh; }

		n_win_scrollbar_move( h, x, sy, sx, sh, n_posix_false );

//RECT r = n_win_rect_set( NULL, x, sy, sx, sh );
//n_win_box( h->hwnd_parent, NULL, &r, RGB( 0,200,255 ) );
	} else {
		n_win_scrollbar_show( h, n_posix_false );
	}

	if ( w->rcsy > w->csy )
	{
		n_win_scrollbar_show( v, n_posix_true );

		n_type_gfx sx = w->csx;
		n_type_gfx sy = w->csy;

		if ( is_lefthanded ) { sx = 0; }

		n_win_scrollbar_move( v, sx, 0, sv, sy, n_posix_false );
	} else {
		n_win_scrollbar_show( v, n_posix_false );
	}


	if ( w->state == SIZE_MAXIMIZED )
	{
		n_type_gfx x = w->csx;
		if ( is_lefthanded ) { x = 0; }

		RECT r = n_win_rect_set( NULL, x, w->csy, sh, sv );
		n_win_box( h->hwnd_parent, NULL, &r, color_corner );

		h->corner_onoff = n_posix_true;
		v->corner_onoff = n_posix_true;
	} else {
		h->corner_onoff = n_posix_false;
		v->corner_onoff = n_posix_false;
	}


	return;
}

void
n_win_scrollbar_client( n_win_scrollbar *h, n_win_scrollbar *v, n_win *w, COLORREF color_corner )
{

	if ( w->state == SIZE_MAXIMIZED )
	{
		n_posix_bool is_lefthanded = n_win_is_lefthanded();

		n_type_gfx sh = n_win_scrollbar_stdsize( h );
		n_type_gfx sv = n_win_scrollbar_stdsize( v );


		n_type_gfx x = w->csx;
		if ( is_lefthanded ) { x = 0; }

		RECT r = n_win_rect_set( NULL, x, w->csy, sh, sv );
		n_win_box( h->hwnd_parent, NULL, &r, color_corner );


		h->corner_onoff = n_posix_true;
		v->corner_onoff = n_posix_true;
	} else {
		h->corner_onoff = n_posix_false;
		v->corner_onoff = n_posix_false;
	}


	return;
}


#endif // _H_NONNON_WIN32_WIN_SCROLLBAR


