// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lole32




#ifndef _H_NONNON_WIN32_OLE_DEBUG
#define _H_NONNON_WIN32_OLE_DEBUG




#include "../../neutral/posix.c"


#include <ole2.h>




void
n_win_com_debug_guid2str( GUID guid, n_posix_char *ret )
{

	n_posix_sprintf_literal
	(
		ret,
		"{%08lx-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x}",
		guid.Data1,
		guid.Data2,
		guid.Data3,
		guid.Data4[ 0 ],
		guid.Data4[ 1 ],
		guid.Data4[ 2 ],
		guid.Data4[ 3 ],
		guid.Data4[ 4 ],
		guid.Data4[ 5 ],
		guid.Data4[ 6 ],
		guid.Data4[ 7 ]
	);


	return;
}

void
n_win_com_debug_cf2string( int cfFormat )
{

	n_posix_char str[ MAX_PATH ];


	GetClipboardFormatName( cfFormat, str, MAX_PATH );

	n_posix_debug_literal( "%d : %x : %s", cfFormat, cfFormat, str );


	return;
}

void
n_win_com_debug_data( FORMATETC *pFormatetc, STGMEDIUM *pmedium )
{

	n_posix_debug_literal
	(
		"%04x %04x %04x %04x %04x : %04x %04x %04x",
		pFormatetc->cfFormat,
		pFormatetc->ptd,
		pFormatetc->dwAspect,
		pFormatetc->lindex,
		pFormatetc->tymed,
		pmedium->tymed,
		pmedium->hGlobal,
		pmedium->pUnkForRelease
	);


	return;
}


#endif // _H_NONNON_WIN32_OLE_DEBUG

