// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_SOUND
#define _H_NONNON_MAC_SOUND




#import <AVFoundation/AVFoundation.h>




#define n_mac_sound_wav_init( wav_name ) n_mac_sound_init( wav_name, @"wav" )

AVAudioPlayer*
n_mac_sound_init( NSString *resource_name, NSString *ext )
{

	// [!] : resource_name
	//
	//	[ how to register ]
	//
	//		DnD to left side of Xcode
	//
	//	[ pitfalls ]
	//
	//		resource_name needs no extension
	//		for example : "mew.wav" => "mew" and "wav"


	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:resource_name ofType:ext];
//NSLog( @"%@", path );

	NSURL    *url  = [NSURL fileURLWithPath:path];
//NSLog( @"%@", url );

	return [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
}

void
n_mac_sound_loop_count( AVAudioPlayer *player, int value )
{

	// [!] : -1 for value : infinite loop playback

	player.numberOfLoops = value;


	return;
}

#define n_mac_sound_play(  player ) [player  play]
#define n_mac_sound_stop(  player ) [player  stop]
#define n_mac_sound_pause( player ) [player pause]




// [!] : if you want more speed like games, use this

// [x] : "throwing -10878" is logged : maybe bug

static AVAudioEngine *n_mac_sound_engine = NULL;

typedef struct {

	AVAudioFile          *file;

	AVAudioPlayerNode    *player;
	AVAudioUnitVarispeed *varispeed;
	AVAudioMixerNode     *mixer;

} n_mac_sound2;

void
n_mac_sound2_init( n_mac_sound2 *p, NSString *resource_name, NSString *ext )
{

	if ( n_mac_sound_engine == NULL )
	{
		n_mac_sound_engine = [[AVAudioEngine alloc] init];
	}


	NSBundle    *main = [NSBundle mainBundle];
	NSString    *path = [main pathForResource:resource_name ofType:ext];
	NSURL       *url  = [NSURL fileURLWithPath:path];
	AVAudioFile *file = [[AVAudioFile alloc] initForReading:url error:nil];

	p->file = file;


	p->player    = [[AVAudioPlayerNode    alloc] init];
	p->varispeed = [[AVAudioUnitVarispeed alloc] init];
	p->mixer     = [[AVAudioMixerNode     alloc] init];

	[n_mac_sound_engine attachNode:p->player   ];
	[n_mac_sound_engine attachNode:p->varispeed];
	[n_mac_sound_engine attachNode:p->mixer    ];

	[n_mac_sound_engine connect:p->player    to:p->varispeed                     format:nil];
	[n_mac_sound_engine connect:p->varispeed to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer     to:n_mac_sound_engine.mainMixerNode format:nil];


	[n_mac_sound_engine prepare];


	return;
}

void
n_mac_sound2_stop( n_mac_sound2 *p )
{
//NSLog( @"n_mac_sound2_stop" );


	[p->player stop];


	[n_mac_sound_engine connect:p->player    to:p->varispeed                     format:nil];
	[n_mac_sound_engine connect:p->varispeed to:p->mixer                         format:nil];
	[n_mac_sound_engine connect:p->mixer     to:n_mac_sound_engine.mainMixerNode format:nil];


	return;
}

void
n_mac_sound2_play( n_mac_sound2 *p )
{
//NSLog( @"n_mac_sound2_play" );


	// [x] : LM2    : slowdown
	// [x] : Typing : delay

	//if ( n_mac_sound_engine.running ) { n_mac_sound2_stop( p ); }


	// [Needed] : do every time

	[n_mac_sound_engine startAndReturnError:NULL];


	// [Needed] : do every time

	[p->player scheduleFile:p->file
	                 atTime:nil
	      completionHandler:nil
	];


	[p->player play];


	return;
}




#endif // _H_NONNON_MAC_SOUND


