//
//  AppDelegate.m
//  Nonnon Typing
//
//  Created by のんのん on 2023/08/18.
//




#import "AppDelegate.h"


#include "n_game.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonGame *n_game;

@property (weak) IBOutlet NSMenuItem *n_menu_warm_up;
@property (weak) IBOutlet NSMenuItem *n_menu_trainer;
@property (weak) IBOutlet NSMenuItem *n_menu_free;

@end




@implementation AppDelegate




- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];


	[_n_game n_mac_game_canvas_resize:_window width:-1 height:-1];


	[_n_game NonnonTypingScaleFactorSet:[_window backingScaleFactor] ];


	[_n_game NonnonTypingMenuSet:N_TYPING_MODE_WARM_UP menu:_n_menu_warm_up];
	[_n_game NonnonTypingMenuSet:N_TYPING_MODE_TRAINER menu:_n_menu_trainer];
	[_n_game NonnonTypingMenuSet:N_TYPING_MODE_FREE    menu:_n_menu_free   ];

	NSString *nsstr = n_mac_settings_read( @"mode" );
	if ( 0 == [nsstr compare:@"Warm-up"] )
	{
		[_n_game NonnonTypingModeSet:N_TYPING_MODE_WARM_UP forced:YES];
	} else
	if ( 0 == [nsstr compare:@"Trainer"] )
	{
		[_n_game NonnonTypingModeSet:N_TYPING_MODE_TRAINER forced:YES];
	} else
	if ( 0 == [nsstr compare:@"Free"] )
	{
		[_n_game NonnonTypingModeSet:N_TYPING_MODE_FREE    forced:YES];
	} else {
		// [!] : Default
		[_n_game NonnonTypingModeSet:N_TYPING_MODE_WARM_UP forced:YES];
	}

	[_n_game NonnonTypingFlush];

}




- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	[_n_game NonnonTypingSettingsWrite];

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}




- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}



- (IBAction)n_typing_mode_warm_up_method:(id)sender {

	[_n_game NonnonTypingModeSet:N_TYPING_MODE_WARM_UP forced:NO];

}

- (IBAction)n_typing_mode_trainer_method:(NSMenuItem *)sender {

	[_n_game NonnonTypingModeSet:N_TYPING_MODE_TRAINER forced:NO];

}

- (IBAction)n_typing_mode_free_method:(NSMenuItem *)sender {

	[_n_game NonnonTypingModeSet:N_TYPING_MODE_FREE forced:NO];

}




- (IBAction)n_typing_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"Nonnon Typing" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}




@end
